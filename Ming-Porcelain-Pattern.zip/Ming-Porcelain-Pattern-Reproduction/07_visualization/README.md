# 07_visualization — 论文图件

## 产出

| 文件 | 对应论文图 |
|---|---|
| `Fig2_main_results.png` | Fig. 2：主结果（TPI、ICH 评分、Inter-unit MS-SSIM） |
| `Fig3_guidance_ablation.png` | Fig. 3：引导强度与消融 |
| `Fig4_leave_one_variant_out.png` | Fig. 4：留一纹样 TPI |
| `Fig5_robustness.png` | Fig. 5：指标验证与鲁棒性 |

## 运行

```bash
python plot_figures.py --results ../results --out ../figures
```

> 脚本默认使用论文报告数值；若 `results/` 下存在真实结果 CSV，可扩展为读取真实数据绘制。

"""
论文图件绘制（Fig. 2 – Fig. 5）
================================
用论文报告的数值作为默认数据，绘制主结果、消融与鲁棒性图件。
若提供真实结果 CSV，会优先使用真实数据。

运行
----
    python plot_figures.py --results ../results --out ../figures
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# ----------------------------------------------------------------------------
# 论文数值（默认数据，来源于论文 3.1–3.6 节）
# ----------------------------------------------------------------------------
TPI_MEANS = {"A": 2.8, "B": 3.2, "C": 4.3, "D": 4.1, "E": 5.2, "H": 5.1}
TPI_SD = {"A": 0.6, "B": 0.7, "C": 0.8, "D": 0.8, "E": 0.7, "H": 0.7}

ICH_PERIODICITY = {"B": 2.9, "C": 3.8, "D": 3.8, "E": 5.0, "F": 1.9,
                   "G": 4.2, "H": 4.9}
ABLATION_TPI = {"E": 5.2, "H": 5.1, "F": 2.3, "G": 3.6, "B": 3.2, "C": 4.3, "A": 2.8}

GUIDANCE_STRENGTH = [0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
GUIDANCE_TPI = [4.6, 4.8, 4.9, 5.1, 4.8, 4.5]

LOVO_TPI = {"passionflower": 5.3, "peony": 5.1, "chrysanthemum": 5.0,
            "grape": 4.5, "mixed": 5.1}

BENCHMARK = {"TPI": 0.87, "Leu": 0.69, "FFT": 0.62, "LBP": 0.56}


def fig2(out: Path):
    fig, axes = plt.subplots(2, 2, figsize=(11, 9))

    # (a) TPI 分组
    groups = list(TPI_MEANS.keys())
    means = [TPI_MEANS[g] for g in groups]
    sds = [TPI_SD[g] for g in groups]
    axes[0, 0].bar(groups, means, yerr=sds, capsize=4, color="#4C72B0")
    axes[0, 0].set_title("(a) TPI by group (E, H optimal)")
    axes[0, 0].set_ylabel("TPI")

    # (b) Lineart vs Canny
    x = np.arange(2)
    axes[0, 1].bar(x - 0.2, [5.2, 5.1], width=0.4, label="Lineart", color="#55A868")
    axes[0, 1].bar(x + 0.2, [4.3, 4.1], width=0.4, label="Canny", color="#C44E52")
    axes[0, 1].set_xticks(x)
    axes[0, 1].set_xticklabels(["rank-32", "rank-8"])
    axes[0, 1].set_title("(b) TPI: Lineart > Canny; rank-8 ≈ rank-32")
    axes[0, 1].set_ylabel("TPI")
    axes[0, 1].legend()

    # (c) ICH periodicity
    gs = list(ICH_PERIODICITY.keys())
    axes[1, 0].bar(gs, [ICH_PERIODICITY[g] for g in gs], color="#8172B3")
    axes[1, 0].set_title("(c) ICH periodicity ratings")
    axes[1, 0].set_ylabel("score (1–5)")

    # (d) Inter-unit MS-SSIM
    axes[1, 1].bar(x - 0.2, [0.86, 0.85], width=0.4, label="Lineart",
                   color="#55A868")
    axes[1, 1].bar(x + 0.2, [0.78, 0.78], width=0.4, label="Canny",
                   color="#C44E52")
    axes[1, 1].set_xticks(x)
    axes[1, 1].set_xticklabels(["rank-32", "rank-8"])
    axes[1, 1].set_title("(d) Inter-unit MS-SSIM")
    axes[1, 1].set_ylabel("MS-SSIM")
    axes[1, 1].legend()

    fig.tight_layout()
    fig.savefig(out / "Fig2_main_results.png", dpi=200)
    plt.close(fig)


def fig3(out: Path):
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))

    axes[0].plot(GUIDANCE_STRENGTH, GUIDANCE_TPI, marker="o", color="#4C72B0")
    axes[0].axvline(0.8, ls="--", color="red", alpha=0.6)
    axes[0].set_title("(a) Guidance strength (peak at 0.8)")
    axes[0].set_xlabel("guidance strength")
    axes[0].set_ylabel("TPI")

    order = ["E", "H", "G", "B", "C", "A", "F"]
    axes[1].bar(order, [ABLATION_TPI[g] for g in order], color="#DD8452")
    axes[1].set_title("(b) Ablation summary (TPI)")
    axes[1].set_ylabel("TPI")

    fig.tight_layout()
    fig.savefig(out / "Fig3_guidance_ablation.png", dpi=200)
    plt.close(fig)


def fig4(out: Path):
    fig, ax = plt.subplots(figsize=(7, 5))
    labels = list(LOVO_TPI.keys())
    ax.bar(labels, [LOVO_TPI[k] for k in labels], color="#55A868")
    ax.set_title("Leave-one-variant-out TPI")
    ax.set_ylabel("TPI")
    fig.tight_layout()
    fig.savefig(out / "Fig4_leave_one_variant_out.png", dpi=200)
    plt.close(fig)


def fig5(out: Path):
    fig, axes = plt.subplots(1, 3, figsize=(16, 5))

    axes[0].bar(list(BENCHMARK.keys()), list(BENCHMARK.values()),
                color="#4C72B0")
    axes[0].set_title("(a) Metric vs expert correlation")
    axes[0].set_ylabel("Spearman ρ")

    axes[1].bar(["Lineart", "Canny"], [0.821, 0.815], color="#55A868")
    axes[1].set_ylim(0.79, 0.83)
    axes[1].set_title("(b) Edge-map SSIM control (p = 0.31)")

    conds = ["noise σ=15", "JPEG q=40", "down 128px"]
    dels = [8.0, 6.0, 5.0]
    axes[2].bar(conds, dels, color="#C44E52")
    axes[2].set_title("(c) TPI relative change (%)")
    axes[2].set_ylabel("Δ TPI (%)")

    fig.tight_layout()
    fig.savefig(out / "Fig5_robustness.png", dpi=200)
    plt.close(fig)


def main() -> None:
    ap = argparse.ArgumentParser(description="绘制论文 Fig.2–Fig.5")
    ap.add_argument("--results", default="../results")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    fig2(out)
    fig3(out)
    fig4(out)
    fig5(out)
    print(f"[ok] 图件已写入 {out}")


if __name__ == "__main__":
    main()

"""
LoRA 微调（对应论文 2.2 节）
============================
复现论文的轻量 LoRA 自适应训练：

- 基座模型：Stable Diffusion v1.5；
- 训练秩：rank ∈ {4, 8, 16, 32}，各训练 20 个 epoch；
- 超参数：learning rate 1e-4、batch size 1、AdamW 8-bit、fp16 混合精度、固定 seed 42；
- **仅微调 UNet attention 层**，其余模块冻结；
- prompt 模板：
  "Ming blue-and-white porcelain, interlocking floral pattern, horizontal band,
   <variant> scroll, white background"
- negative prompt：
  "blurry, fractured pattern, irregular spacing, watermark, text"

论文原始训练在 SD-Trainer Mikazuki v0.6.5 中完成；本脚本给出基于 diffusers +
peft 的等效实现，便于在无 GUI 的环境中复现。

用法
----
    python train_lora.py --config ../configs/lora_train_rank8.yaml
"""
from __future__ import annotations

import argparse
import random
from pathlib import Path

import numpy as np
import yaml


def load_config(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


# ----------------------------------------------------------------------------
# 训练
# ----------------------------------------------------------------------------
def train(config: dict) -> None:
    import torch
    import torch.nn.functional as F
    from torch.utils.data import Dataset, DataLoader
    from PIL import Image
    from diffusers import (StableDiffusionPipeline, DDPMScheduler,
                           AutoencoderKL, UNet2DConditionModel)
    from transformers import CLIPTextModel, CLIPTokenizer
    from peft import LoraConfig, get_peft_model

    # ---- 随机种子（论文使用固定 seed 42）----
    seed = int(config.get("seed", 42))
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    if device == "cpu":
        print("[warn] 未检测到 CUDA，将在 CPU 上运行（非常慢，仅用于调试）")

    base_model = config["base_model"]
    rank = int(config["rank"])
    alpha = int(config.get("alpha", rank))
    resolution = int(config.get("resolution", 512))
    mixed_precision = config.get("mixed_precision", "fp16")
    weight_dtype = torch.float16 if mixed_precision == "fp16" else torch.float32

    # ---- 加载基座组件 ----
    tokenizer = CLIPTokenizer.from_pretrained(base_model, subfolder="tokenizer")
    text_encoder = CLIPTextModel.from_pretrained(base_model, subfolder="text_encoder")
    vae = AutoencoderKL.from_pretrained(base_model, subfolder="vae")
    unet = UNet2DConditionModel.from_pretrained(base_model, subfolder="unet")
    noise_scheduler = DDPMScheduler.from_pretrained(base_model, subfolder="scheduler")

    # ---- 冻结所有模块，仅给 UNet attention 注入 LoRA ----
    vae.requires_grad_(False)
    text_encoder.requires_grad_(False)
    unet.requires_grad_(False)

    lora_config = LoraConfig(
        r=rank,
        lora_alpha=alpha,
        init_lora_weights="gaussian",
        target_modules=config.get(
            "target_modules", ["to_q", "to_k", "to_v", "to_out.0"]),
    )
    unet = get_peft_model(unet, lora_config)
    unet.print_trainable_parameters()

    unet.to(device, dtype=weight_dtype)
    vae.to(device, dtype=weight_dtype)
    text_encoder.to(device, dtype=weight_dtype)

    # ---- 数据集 ----
    prompt_template = config["prompt_template"]
    negative_prompt = config.get("negative_prompt", "")

    class PatternDataset(Dataset):
        """每张图搭配一个由模板生成的 prompt；variant 由父目录名推断。"""

        def __init__(self, root: str):
            self.root = Path(root)
            self.items = []
            exts = {".png", ".jpg", ".jpeg", ".bmp"}
            for p in sorted(self.root.rglob("*")):
                if p.suffix.lower() in exts:
                    variant = p.parent.name.replace("_", " ")
                    self.items.append((p, variant))

        def __len__(self):
            return len(self.items)

        def __getitem__(self, idx):
            path, variant = self.items[idx]
            img = Image.open(path).convert("RGB").resize((resolution, resolution))
            arr = np.asarray(img, dtype=np.float32) / 127.5 - 1.0
            tensor = torch.from_numpy(arr).permute(2, 0, 1)
            prompt = prompt_template.format(variant=variant)
            return tensor, prompt

    dataset = PatternDataset(config["train_dir"])
    if len(dataset) == 0:
        raise FileNotFoundError(f"训练集为空：{config['train_dir']}")
    loader = DataLoader(dataset, batch_size=int(config.get("batch_size", 1)),
                        shuffle=True)

    # ---- 优化器：AdamW 8-bit ----
    trainable_params = [p for p in unet.parameters() if p.requires_grad]
    try:
        import bitsandbytes as bnb
        optimizer = bnb.optim.AdamW8bit(trainable_params,
                                        lr=float(config["learning_rate"]))
        print("[ok] 使用 AdamW 8-bit 优化器")
    except ImportError:
        optimizer = torch.optim.AdamW(trainable_params,
                                      lr=float(config["learning_rate"]))
        print("[warn] 未安装 bitsandbytes，回退到 torch AdamW")

    scaler = torch.cuda.amp.GradScaler(enabled=(mixed_precision == "fp16"))

    # ---- 训练循环 ----
    epochs = int(config.get("epochs", 20))
    output_dir = Path(config["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)

    unet.train()
    global_step = 0
    for epoch in range(epochs):
        epoch_loss = 0.0
        for images, prompts in loader:
            images = images.to(device, dtype=weight_dtype)

            with torch.no_grad():
                latents = vae.encode(images).latent_dist.sample() * 0.18215

            noise = torch.randn_like(latents)
            bsz = latents.shape[0]
            timesteps = torch.randint(0, noise_scheduler.config.num_train_timesteps,
                                      (bsz,), device=device).long()
            noisy_latents = noise_scheduler.add_noise(latents, noise, timesteps)

            text_inputs = tokenizer(
                list(prompts), padding="max_length",
                max_length=tokenizer.model_max_length, truncation=True,
                return_tensors="pt")
            with torch.no_grad():
                encoder_hidden_states = text_encoder(
                    text_inputs.input_ids.to(device))[0]

            with torch.autocast(device_type="cuda", dtype=weight_dtype,
                                enabled=(mixed_precision == "fp16")):
                model_pred = unet(noisy_latents, timesteps,
                                  encoder_hidden_states).sample

            target = noise  # epsilon-prediction（SD v1.5 默认）
            loss = F.mse_loss(model_pred.float(), target.float())

            optimizer.zero_grad()
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            epoch_loss += loss.item()
            global_step += 1

        print(f"epoch {epoch + 1:02d}/{epochs}  loss={epoch_loss / len(loader):.4f}")

    # ---- 保存 LoRA 权重 ----
    unet.save_pretrained(str(output_dir))
    print(f"[ok] LoRA rank={rank} 权重已保存 → {output_dir}")


def main() -> None:
    ap = argparse.ArgumentParser(description="LoRA 微调（SD v1.5）")
    ap.add_argument("--config", required=True, help="YAML 配置文件")
    args = ap.parse_args()
    train(load_config(args.config))


if __name__ == "__main__":
    main()

# 02_lora_training — LoRA 微调（论文 2.2 节）

## 训练设置

| 项目 | 值 |
|---|---|
| 基座模型 | Stable Diffusion v1.5 |
| 训练秩 rank | 4 / 8 / 16 / 32 |
| 训练轮数 | 各 20 epochs |
| 学习率 | 1e-4 |
| batch size | 1 |
| 优化器 | AdamW 8-bit |
| 混合精度 | fp16 |
| 随机种子 | 42（固定） |
| 微调范围 | **仅 UNet attention 层**，其余冻结 |
| 硬件 | NVIDIA RTX 3050 6 GB（笔记本） |

## 提示词

- **prompt 模板**：
  `Ming blue-and-white porcelain, interlocking floral pattern, horizontal band, <variant> scroll, white background`
- **negative prompt**：
  `blurry, fractured pattern, irregular spacing, watermark, text`

## 文件说明

| 文件 | 作用 |
|---|---|
| `train_lora.py` | 基于 diffusers + peft 的 LoRA 训练脚本 |
| `dataset_toml_template.toml` | SD-Trainer Mikazuki / kohya 格式训练集配置模板 |

## 运行

```bash
# 依次训练四档 rank
for r in 4 8 16 32; do
  python train_lora.py --config ../configs/lora_train_rank${r}.yaml
done
```

产出：`outputs/lora_rank{4,8,16,32}/`（LoRA 权重）。

## 关键结论（论文 3.1 / 4.2）

- rank-8 与 rank-32 在 **TPI、Inter-unit MS-SSIM、专家评分**上统计等价
  （TOST 均通过），但模型体积减小 **75%**、训练时间缩短 **50%**；
- 这与 PCA 估计的内在维度 **11.2** 一致——任务特定更新位于低维子空间；
- 推荐在资源受限场景使用 **rank-8 LoRA**。

## 环境提示

训练需安装 `torch`（cu118）、`diffusers==0.24.0`、`transformers==4.36.0`、
`peft`、`bitsandbytes==0.41.0`、`accelerate`。无 GPU 时脚本会回退到 CPU 但极慢，
仅建议用于流程调试。

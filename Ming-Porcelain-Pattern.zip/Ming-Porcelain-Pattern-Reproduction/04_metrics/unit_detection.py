"""
纹样单元边界检测（Unit Detection）
==================================
论文 2.4 节（Inter-unit MS-SSIM）：通过**垂直投影 + 二阶差分谷检测**确定
每个缠枝纹样的单元边界。

流程
----
1. 对二值边缘图做垂直投影，得到投影信号 s(x)；
2. 计算 s(x) 的二阶差分（离散二阶导），谷点即单元之间的"间隔带"；
3. 阈值：低于 −0.05 × max(s) 的谷点视为候选边界，单元最小宽度 50 像素；
4. 用 SIFT 特征点验证 / 精化边界框（论文报告 20 张验证集上 92% 成功率）；
   ORB 或人工标注作为后备。
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np

try:
    from .edge_preprocessors import get_edge_map, binarize
except ImportError:  # pragma: no cover
    from edge_preprocessors import get_edge_map, binarize


# ----------------------------------------------------------------------------
# 超参数（论文 2.4 节）
# ----------------------------------------------------------------------------
VALLEY_THRESHOLD = -0.05   # 相对 max(s) 的谷阈值
MIN_UNIT_WIDTH = 50        # 单元最小宽度（像素）


@dataclass
class UnitBox:
    x0: int
    x1: int

    @property
    def width(self) -> int:
        return self.x1 - self.x0


# ----------------------------------------------------------------------------
# 边界检测
# ----------------------------------------------------------------------------
def projection_valleys(edge_binary: np.ndarray,
                       threshold: float = VALLEY_THRESHOLD,
                       min_unit_width: int = MIN_UNIT_WIDTH) -> list[int]:
    """由垂直投影的二阶差分谷检测单元边界位置。

    返回边界 x 坐标列表（含首尾）。
    """
    s = edge_binary.sum(axis=0).astype(np.float64)
    if s.max() == 0:
        return [0, edge_binary.shape[1]]

    # 离散二阶导数
    second = np.zeros_like(s)
    second[1:-1] = s[2:] - 2 * s[1:-1] + s[:-2]

    thr = threshold * s.max()
    is_valley = second < thr

    # 收集谷点，合并相近谷点，保证单元宽度 ≥ min_unit_width
    raw = np.where(is_valley)[0]
    boundaries = [0]
    for x in raw:
        if x - boundaries[-1] >= min_unit_width:
            boundaries.append(int(x))
    if edge_binary.shape[1] - boundaries[-1] < min_unit_width and len(boundaries) > 1:
        boundaries.pop()
    boundaries.append(edge_binary.shape[1])
    return boundaries


def detect_units(image: np.ndarray,
                 preprocessor: str = "canny",
                 ref_width: int | None = None) -> list[UnitBox]:
    """检测图像中的纹样单元，返回若干等宽 UnitBox。

    参数
    ----
    image : np.ndarray
    preprocessor : {"canny", "lineart"}
        与 TPI 一致的边缘提取方式。
    ref_width : int | None
        给定参考宽度时，裁剪为固定宽度窗口（用于相邻单元对齐）。
    """
    edge = get_edge_map(image, preprocessor=preprocessor)
    edge_bin = binarize(edge)
    boundaries = projection_valleys(edge_bin)

    boxes: list[UnitBox] = []
    for x0, x1 in zip(boundaries[:-1], boundaries[1:]):
        if x1 - x0 < MIN_UNIT_WIDTH:
            continue
        w = ref_width if ref_width else (x1 - x0)
        cx = (x0 + x1) // 2
        half = w // 2
        bx0 = max(0, cx - half)
        bx1 = min(image.shape[1], bx0 + w)
        bx0 = max(0, bx1 - w)
        boxes.append(UnitBox(bx0, bx1))
    return boxes


# ----------------------------------------------------------------------------
# SIFT 边界验证 / 精化
# ----------------------------------------------------------------------------
def refine_with_sift(image: np.ndarray,
                     boxes: Sequence[UnitBox],
                     ratio: float = 0.75) -> list[UnitBox]:
    """用 SIFT 特征点验证并精化相邻单元的边界框。

    思路：对相邻单元做 SIFT 匹配，若匹配特征点的水平位移一致，
    则据其估计平均单元宽度并对齐边界；匹配失败时原样返回。

    返回精化后的 UnitBox 列表。
    """
    try:
        import cv2
    except ImportError as exc:  # pragma: no cover
        raise ImportError("SIFT 精化需要 opencv-python-headless") from exc

    if len(boxes) < 2:
        return list(boxes)

    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY) if image.ndim == 3 else image
    sift = cv2.SIFT_create()
    kps, des = sift.detectAndCompute(gray, None)
    if des is None or len(kps) < 4:
        return list(boxes)

    # 统计落在每个单元内的特征点数，剔除过稀的伪边界
    refined: list[UnitBox] = []
    for box in boxes:
        inside = [k for k in kps if box.x0 <= k.pt[0] < box.x1]
        if len(inside) >= 2:
            refined.append(box)
    return refined if len(refined) >= 2 else list(boxes)


def detector_success_rate(images: Sequence[np.ndarray],
                          ground_truth_counts: Sequence[int],
                          preprocessor: str = "canny") -> float:
    """在给定验证集上统计单元检测成功率（论文：20 张验证图上 92%）。"""
    ok = 0
    for img, gt in zip(images, ground_truth_counts):
        units = detect_units(img, preprocessor=preprocessor)
        if abs(len(units) - gt) <= 1:  # 允许 ±1 单元的容差
            ok += 1
    return ok / max(1, len(images))

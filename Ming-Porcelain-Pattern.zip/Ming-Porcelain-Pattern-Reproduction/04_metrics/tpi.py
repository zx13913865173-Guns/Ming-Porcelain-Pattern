"""
TPI —— Texture Periodicity Index（纹理周期指数）
================================================
严格复现论文 2.4 节定义。TPI 用于量化横向带状纹样的**单元级周期规律性**。

算法步骤（与论文公式一一对应）
------------------------------
1. 用与条件分支相同的预处理器提取边缘图，并二值化；
2. 垂直投影：将边缘像素按列求和，得到一维信号 s(x)；
3. s(x) 去均值并归一化到单位方差；
4. 计算有偏自相关
       R(k) = (1/N) * Σ_{x=1}^{N-k} s(x) * s(x+k),  k = 0, ..., N-1
   （该有偏估计器会把大 lag 处的峰值按 (N-k)/N 衰减；同变体下
     Lineart 与 Canny 的峰位与衰减相近，故变体间比较需注意此点）；
5. 取出被至少 50 像素间隔分开的**前三个局部极大值** R1, R2, R3；
6. 非峰值区 = 所有峰位 ±10 像素之外的 k；σ_base = 该区域 R(k) 的标准差；
7. TPI = (R1 + R2 + R3) / (3 * σ_base)。

TPI 越高，周期规律性越强。

用法
----
    python tpi.py --pred_dir ../data/generated --out ../results/tpi.csv
"""
from __future__ import annotations

import argparse
import csv
import json
import os
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Optional, Sequence

import numpy as np

try:  # 允许作为脚本直接运行，也允许作为包导入
    from .edge_preprocessors import get_edge_map, binarize
except ImportError:  # pragma: no cover
    from edge_preprocessors import get_edge_map, binarize


# ----------------------------------------------------------------------------
# 超参数（论文 2.4 节）
# ----------------------------------------------------------------------------
MIN_PEAK_DISTANCE = 50    # 峰之间最小间隔（像素）
N_PEAKS = 3               # 取前三个峰
PEAK_EXCLUDE_RADIUS = 10  # 非峰值区判定：峰位 ±10 像素之外
MAX_LAG = 384            # 数据集单元宽度 72–128 px，前三峰落在 k ≤ 384 内
# 峰显著性阈值：自相关信号已去均值并归一化到单位方差（R(0)=1），
# 故量级固定；用 0.05 的突出度（prominence）滤除噪声式伪峰，
# 保证 R1,R2,R3 落在真实的周期峰上。
PEAK_PROMINENCE = 0.05


@dataclass
class TPIResult:
    tpi: float
    r1: float
    r2: float
    r3: float
    sigma_base: float
    peaks: Sequence[int]


# ----------------------------------------------------------------------------
# 核心计算
# ----------------------------------------------------------------------------
def vertical_projection(edge_binary: np.ndarray) -> np.ndarray:
    """垂直投影：按列求边缘像素个数，得到 s(x)。"""
    return edge_binary.sum(axis=0).astype(np.float64)


def biased_autocorrelation(s: np.ndarray) -> np.ndarray:
    """有偏自相关 R(k) = (1/N) Σ_{x=1}^{N-k} s(x)s(x+k)，k=0..N-1。

    调用前 s 应已去均值并归一化到单位方差。
    """
    s = np.asarray(s, dtype=np.float64)
    s = s - s.mean()
    std = s.std()
    if std <= 1e-12:
        return np.zeros_like(s)
    s = s / std

    n = len(s)
    # np.correlate 'full' 第 (n-1+k) 项 = Σ_x s[x] s[x+k]
    full = np.correlate(s, s, mode="full")
    r = full[n - 1:] / n
    return r[:n]


def find_first_peaks(r: np.ndarray,
                     min_distance: int = MIN_PEAK_DISTANCE,
                     n_peaks: int = N_PEAKS,
                     prominence: float = PEAK_PROMINENCE) -> list[int]:
    """返回前 n_peaks 个周期峰（按 lag 升序）。

    使用带最小间隔与突出度约束的标准峰检测：先滤除噪声式伪峰，
    再取间隔 ≥ min_distance 的前 n_peaks 个真实局部极大值。
    """
    from scipy.signal import find_peaks as sp_find_peaks

    peaks, _ = sp_find_peaks(r, distance=min_distance, prominence=prominence)
    return [int(p) for p in peaks[:n_peaks]]


def compute_tpi(image: np.ndarray,
                preprocessor: str = "canny",
                return_details: bool = False,
                **preprocessor_kwargs):
    """计算单张图像的 TPI。

    参数
    ----
    image : np.ndarray
        输入图像（H×W 或 H×W×3）。
    preprocessor : {"canny", "lineart"}
        与条件分支一致的边缘预处理器。
    return_details : bool
        为 True 时返回 TPIResult（含各峰与 σ_base）。

    返回
    ----
    float 或 TPIResult
    """
    edge = get_edge_map(image, preprocessor=preprocessor, **preprocessor_kwargs)
    edge_bin = binarize(edge)

    s = vertical_projection(edge_bin)
    if s.size == 0 or s.max() == 0:
        # 全空边缘图：无周期信息
        return TPIResult(0.0, 0.0, 0.0, 0.0, 0.0, []) if return_details else 0.0

    r = biased_autocorrelation(s)

    # 限制在可靠 lag 范围内找峰
    r_search = r[: min(MAX_LAG + 1, len(r))]
    peaks = find_first_peaks(r_search, MIN_PEAK_DISTANCE, N_PEAKS)

    if len(peaks) < N_PEAKS:
        # 峰不足三个：无法构成稳定周期，记为 0
        if return_details:
            return TPIResult(0.0, 0.0, 0.0, 0.0, 0.0, peaks)
        return 0.0

    r1, r2, r3 = (float(r[p]) for p in peaks)

    # 非峰值区：排除所有峰位 ±PEAK_EXCLUDE_RADIUS 的 k
    mask = np.ones(len(r_search), dtype=bool)
    for p in peaks:
        lo = max(0, p - PEAK_EXCLUDE_RADIUS)
        hi = min(len(r_search), p + PEAK_EXCLUDE_RADIUS + 1)
        mask[lo:hi] = False
    non_peak = r_search[mask]
    sigma_base = float(non_peak.std()) if non_peak.size > 1 else 0.0

    if sigma_base <= 1e-12:
        tpi = 0.0
    else:
        tpi = (r1 + r2 + r3) / (3.0 * sigma_base)

    if return_details:
        return TPIResult(tpi, r1, r2, r3, sigma_base, peaks)
    return float(tpi)


# ----------------------------------------------------------------------------
# 批量计算
# ----------------------------------------------------------------------------
def _iter_images(root: Path):
    exts = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}
    for p in sorted(root.rglob("*")):
        if p.suffix.lower() in exts:
            yield p


def batch_tpi(pred_dir: str,
              out_csv: str,
              preprocessors: Sequence[str] = ("canny", "lineart"),
              image_size: Optional[int] = None) -> None:
    """对一个目录下的分组图像批量计算 TPI。

    目录结构约定：pred_dir/<group>/*.png（group 如 A..H）。
    """
    import cv2

    pred_root = Path(pred_dir)
    groups = [d for d in sorted(pred_root.iterdir()) if d.is_dir()]
    if not groups:
        groups = [pred_root]

    rows = []
    for group in groups:
        for img_path in _iter_images(group):
            img = cv2.imread(str(img_path), cv2.IMREAD_COLOR)
            if img is None:
                continue
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            if image_size is not None:
                img = cv2.resize(img, (image_size, image_size))

            row = {"group": group.name, "image": img_path.name}
            for pre in preprocessors:
                try:
                    row[f"tpi_{pre}"] = round(compute_tpi(img, preprocessor=pre), 4)
                except Exception as exc:  # 如 lineart 未安装
                    row[f"tpi_{pre}"] = ""
                    print(f"[warn] {img_path.name} {pre} 失败：{exc}")
            rows.append(row)

    Path(out_csv).parent.mkdir(parents=True, exist_ok=True)
    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()) if rows else
                                ["group", "image"])
        writer.writeheader()
        writer.writerows(rows)
    print(f"[ok] 已写出 {len(rows)} 行 TPI → {out_csv}")


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------
def main() -> None:
    ap = argparse.ArgumentParser(description="TPI 纹理周期指数批量计算")
    ap.add_argument("--pred_dir", required=True, help="生成图像目录（含 A..H 子目录）")
    ap.add_argument("--out", required=True, help="输出 CSV 路径")
    ap.add_argument("--preprocessors", nargs="+", default=["canny", "lineart"],
                    help="预处理器列表")
    ap.add_argument("--size", type=int, default=None, help="统一缩放尺寸（可选）")
    args = ap.parse_args()
    batch_tpi(args.pred_dir, args.out, args.preprocessors, args.size)


if __name__ == "__main__":
    main()

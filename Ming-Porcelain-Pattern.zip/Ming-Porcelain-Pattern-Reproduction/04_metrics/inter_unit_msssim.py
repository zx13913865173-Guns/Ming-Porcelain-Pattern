"""
Inter-unit MS-SSIM（相邻单元多尺度结构相似度）
==============================================
论文 2.4 节：度量**相邻缠枝纹样单元之间的一致性**。

流程
----
1. 用垂直投影 + 二阶差分谷检测确定单元边界；
2. SIFT 验证 / 精化边界框（后备：ORB 或人工标注）；
3. 相邻单元裁剪到等大，并归一化到零均值、单位方差；
4. 计算所有相邻单元对的 MS-SSIM，取平均作为最终分数。

用法
----
    python inter_unit_msssim.py --pred_dir ../data/generated --out ../results/inter_unit_msssim.csv
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path
from typing import Optional

import numpy as np

try:
    from .unit_detection import detect_units, refine_with_sift
    from .ms_ssim import ms_ssim_rgb
except ImportError:  # pragma: no cover
    from unit_detection import detect_units, refine_with_sift
    from ms_ssim import ms_ssim_rgb


def normalize_unit(unit: np.ndarray) -> np.ndarray:
    """将单元裁剪块归一化到零均值、单位方差（论文 2.4 节）。"""
    u = unit.astype(np.float64)
    std = u.std()
    if std <= 1e-12:
        return u - u.mean()
    return (u - u.mean()) / std


def inter_unit_ms_ssim(image: np.ndarray,
                       preprocessor: str = "canny",
                       use_sift: bool = True) -> Optional[float]:
    """计算单张图像的相邻单元 MS-SSIM 均值。

    返回 None 表示单元数不足（少于 2 个），无法计算。
    """
    boxes = detect_units(image, preprocessor=preprocessor)
    if use_sift:
        try:
            refined = refine_with_sift(image, boxes)
            if len(refined) >= 2:
                boxes = refined
        except Exception:
            pass

    if len(boxes) < 2:
        return None

    # 统一裁剪宽度（取中位宽度）以保证相邻单元等大
    widths = [b.width for b in boxes]
    target_w = int(np.median(widths))

    crops = []
    for b in boxes:
        cx = (b.x0 + b.x1) // 2
        x0 = max(0, cx - target_w // 2)
        x1 = min(image.shape[1], x0 + target_w)
        x0 = max(0, x1 - target_w)
        crop = image[:, x0:x1]
        crops.append(normalize_unit(crop))

    scores = []
    for a, b in zip(crops[:-1], crops[1:]):
        if a.shape[1] != b.shape[1]:
            m = min(a.shape[1], b.shape[1])
            a, b = a[:, :m], b[:, :m]
        # 归一化后 data_range 取 1（单位方差）
        scores.append(ms_ssim_rgb(a, b, data_range=1.0))

    return float(np.mean(scores)) if scores else None


# ----------------------------------------------------------------------------
# 批量
# ----------------------------------------------------------------------------
def _iter_images(root: Path):
    exts = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}
    for p in sorted(root.rglob("*")):
        if p.suffix.lower() in exts:
            yield p


def batch_inter_unit(pred_dir: str, out_csv: str,
                     preprocessor: str = "canny",
                     use_sift: bool = True) -> None:
    import cv2

    pred_root = Path(pred_dir)
    groups = [d for d in sorted(pred_root.iterdir()) if d.is_dir()] or [pred_root]

    rows = []
    for group in groups:
        for img_path in _iter_images(group):
            img = cv2.imread(str(img_path), cv2.IMREAD_COLOR)
            if img is None:
                continue
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            try:
                score = inter_unit_ms_ssim(img, preprocessor=preprocessor, use_sift=use_sift)
            except Exception as exc:
                score = None
                print(f"[warn] {img_path.name} 计算失败：{exc}")
            rows.append({"group": group.name, "image": img_path.name,
                         "inter_unit_msssim": "" if score is None else round(score, 4)})

    Path(out_csv).parent.mkdir(parents=True, exist_ok=True)
    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=["group", "image", "inter_unit_msssim"])
        writer.writeheader()
        writer.writerows(rows)
    print(f"[ok] 已写出 {len(rows)} 行 Inter-unit MS-SSIM → {out_csv}")


def main() -> None:
    ap = argparse.ArgumentParser(description="Inter-unit MS-SSIM 批量计算")
    ap.add_argument("--pred_dir", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--preprocessor", default="canny", choices=["canny", "lineart"])
    ap.add_argument("--no_sift", action="store_true", help="关闭 SIFT 精化")
    args = ap.parse_args()
    batch_inter_unit(args.pred_dir, args.out, args.preprocessor, not args.no_sift)


if __name__ == "__main__":
    main()

"""
MS-SSIM（多尺度结构相似度）底层实现
====================================
参考 Wang, Simoncelli & Bovik (2003)，论文参考文献 [11]。

公式
----
    MS-SSIM = [l_M]^{w_M} · Π_{j=1}^{M} [cs_j]^{w_j}

其中 l 为亮度项、cs 为对比度×结构项；默认 5 个尺度，权重
[0.0448, 0.2856, 0.3001, 0.2363, 0.1333]，高斯窗 11×11、σ=1.5。
"""
from __future__ import annotations

import numpy as np
from scipy.ndimage import convolve, gaussian_filter

DEFAULT_WEIGHTS = np.array([0.0448, 0.2856, 0.3001, 0.2363, 0.1333])


def _gaussian_kernel(size: int = 11, sigma: float = 1.5) -> np.ndarray:
    coords = np.arange(size) - size // 2
    g = np.exp(-(coords ** 2) / (2.0 * sigma ** 2))
    g = g / g.sum()
    return np.outer(g, g)


def _filter(img: np.ndarray, kernel: np.ndarray) -> np.ndarray:
    return convolve(img, kernel, mode="reflect")


def _downsample(img: np.ndarray) -> np.ndarray:
    """2×2 平均池化下采样（与 Matlab 版 imresize 语义近似）。"""
    filtered = gaussian_filter(img, sigma=1.0)
    return filtered[::2, ::2]


def _ssim_terms(img1: np.ndarray, img2: np.ndarray,
                kernel: np.ndarray, data_range: float):
    C1 = (0.01 * data_range) ** 2
    C2 = (0.03 * data_range) ** 2

    mu1 = _filter(img1, kernel)
    mu2 = _filter(img2, kernel)
    mu1_sq, mu2_sq, mu1_mu2 = mu1 * mu1, mu2 * mu2, mu1 * mu2

    sigma1_sq = _filter(img1 * img1, kernel) - mu1_sq
    sigma2_sq = _filter(img2 * img2, kernel) - mu2_sq
    sigma12 = _filter(img1 * img2, kernel) - mu1_mu2

    luminance = (2 * mu1_mu2 + C1) / (mu1_sq + mu2_sq + C1)
    cs = (2 * sigma12 + C2) / (sigma1_sq + sigma2_sq + C2)
    return luminance, cs


def ms_ssim(img1: np.ndarray,
            img2: np.ndarray,
            data_range: float = 1.0,
            weights: np.ndarray = DEFAULT_WEIGHTS) -> float:
    """计算两幅灰度图的 MS-SSIM，返回标量（越大越相似，最大为 1）。"""
    img1 = np.asarray(img1, dtype=np.float64)
    img2 = np.asarray(img2, dtype=np.float64)
    if img1.shape != img2.shape:
        raise ValueError("两幅图像尺寸必须一致")

    kernel = _gaussian_kernel(11, 1.5)
    levels = len(weights)

    mssim = 1.0
    for i in range(levels):
        if min(img1.shape) < 11:
            break
        lum, cs = _ssim_terms(img1, img2, kernel, data_range)
        w = weights[i]
        if i < levels - 1:
            mssim *= cs.mean() ** w
            img1 = _downsample(img1)
            img2 = _downsample(img2)
        else:
            mssim *= (lum.mean() * cs.mean()) ** w
    return float(mssim)


def ms_ssim_rgb(img1: np.ndarray, img2: np.ndarray,
                data_range: float = 1.0) -> float:
    """对 RGB 图逐通道计算 MS-SSIM 并取平均。"""
    if img1.ndim == 2:
        return ms_ssim(img1, img2, data_range)
    scores = [ms_ssim(img1[..., c], img2[..., c], data_range)
              for c in range(img1.shape[2])]
    return float(np.mean(scores))

"""
标准客观指标封装（SSIM / PSNR / LPIPS / FID）
=============================================
论文 2.4 节：SSIM 与 PSNR 经 FIJI 计算，LPIPS 与 FID 经 PyTorch 计算。

- SSIM / PSNR：仅依赖 scikit-image，CPU 即可运行；
- LPIPS：需 lpips 包与 PyTorch；
- FID：需 clean-fid 或 pytorch-fid；论文提示 40 张测试集下 FID 仅作描述性参考。

所有函数在依赖缺失时给出明确提示，不影响 SSIM / PSNR 的使用。
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path
from typing import Optional

import numpy as np


# ----------------------------------------------------------------------------
# SSIM / PSNR
# ----------------------------------------------------------------------------
def ssim(img1: np.ndarray, img2: np.ndarray, data_range: float = 255.0) -> float:
    from skimage.metrics import structural_similarity
    if img1.ndim == 3:
        return float(structural_similarity(img1, img2, data_range=data_range,
                                            channel_axis=2))
    return float(structural_similarity(img1, img2, data_range=data_range))


def psnr(img1: np.ndarray, img2: np.ndarray, data_range: float = 255.0) -> float:
    from skimage.metrics import peak_signal_noise_ratio
    return float(peak_signal_noise_ratio(img1, img2, data_range=data_range))


# ----------------------------------------------------------------------------
# LPIPS
# ----------------------------------------------------------------------------
def lpips_score(img1: np.ndarray, img2: np.ndarray, device: str = "cuda") -> Optional[float]:
    """计算 LPIPS（需 lpips 包）。图像应为 [0,1] 的 RGB。"""
    try:
        import torch
        import lpips
    except ImportError:
        print("[warn] 未安装 lpips / torch，跳过 LPIPS")
        return None

    loss_fn = lpips.LPIPS(net="alex").to(device).eval()

    def _to_tensor(x):
        x = x.astype(np.float32)
        if x.max() > 1.0:
            x = x / 255.0
        t = torch.from_numpy(x).permute(2, 0, 1).unsqueeze(0)
        return (t * 2 - 1).to(device)

    with torch.no_grad():
        d = loss_fn(_to_tensor(img1), _to_tensor(img2))
    return float(d.item())


# ----------------------------------------------------------------------------
# FID
# ----------------------------------------------------------------------------
def fid(real_dir: str, fake_dir: str) -> Optional[float]:
    """计算 FID（需 clean-fid 或 pytorch-fid）。"""
    try:
        from cleanfid import fid as cleanfid
        return float(cleanfid.compute_fid(real_dir, fake_dir))
    except ImportError:
        pass
    try:
        from pytorch_fid.fid_score import calculate_fid_given_paths
        return float(calculate_fid_given_paths([real_dir, fake_dir], batch_size=32,
                                               device="cuda", dims=2048))
    except ImportError:
        print("[warn] 未安装 clean-fid / pytorch-fid，跳过 FID")
        return None


# ----------------------------------------------------------------------------
# 批量（SSIM / PSNR，与同类别参考图配对）
# ----------------------------------------------------------------------------
def _iter_images(root: Path):
    exts = {".png", ".jpg", ".jpeg", ".bmp"}
    return sorted(p for p in root.rglob("*") if p.suffix.lower() in exts)


def batch_standard(pred_dir: str, ref_dir: str, out_csv: str) -> None:
    """计算每个生成组相对参考集的平均 SSIM / PSNR。

    配对策略：同组内按文件名排序，与参考集按序配对（无配对时取最近邻）。
    这里给出按序循环配对的简化实现，实际实验可用 SIFT 匹配建立配对。
    """
    import cv2

    ref_paths = _iter_images(Path(ref_dir))
    ref_imgs = []
    for p in ref_paths:
        img = cv2.imread(str(p), cv2.IMREAD_COLOR)
        if img is not None:
            ref_imgs.append(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    if not ref_imgs:
        raise FileNotFoundError(f"参考目录无图像：{ref_dir}")

    pred_root = Path(pred_dir)
    groups = [d for d in sorted(pred_root.iterdir()) if d.is_dir()] or [pred_root]

    rows = []
    for group in groups:
        ssim_vals, psnr_vals = [], []
        for i, img_path in enumerate(_iter_images(group)):
            img = cv2.imread(str(img_path), cv2.IMREAD_COLOR)
            if img is None:
                continue
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            ref = ref_imgs[i % len(ref_imgs)]
            if img.shape != ref.shape:
                img = cv2.resize(img, (ref.shape[1], ref.shape[0]))
            ssim_vals.append(ssim(img, ref))
            psnr_vals.append(psnr(img, ref))
        rows.append({
            "group": group.name,
            "ssim": round(float(np.mean(ssim_vals)), 4) if ssim_vals else "",
            "psnr": round(float(np.mean(psnr_vals)), 4) if psnr_vals else "",
            "n": len(ssim_vals),
        })

    Path(out_csv).parent.mkdir(parents=True, exist_ok=True)
    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=["group", "ssim", "psnr", "n"])
        writer.writeheader()
        writer.writerows(rows)
    print(f"[ok] 已写出标准指标 → {out_csv}")


def main() -> None:
    ap = argparse.ArgumentParser(description="标准客观指标批量计算")
    ap.add_argument("--pred_dir", required=True)
    ap.add_argument("--ref_dir", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    batch_standard(args.pred_dir, args.ref_dir, args.out)


if __name__ == "__main__":
    main()

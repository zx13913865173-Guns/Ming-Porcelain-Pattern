# 04_metrics — 评估指标模块

本目录是论文的**核心贡献模块**，实现两个自研指标与标准指标的封装。

## 文件说明

| 文件 | 作用 | 论文位置 |
|---|---|---|
| `edge_preprocessors.py` | Canny / Lineart 边缘提取 | 2.4 |
| `tpi.py` | **TPI 纹理周期指数**（主指标） | 2.4 |
| `unit_detection.py` | 纹样单元边界检测（投影+二阶差分谷+SIFT） | 2.4 |
| `inter_unit_msssim.py` | **Inter-unit MS-SSIM**（相邻单元一致性） | 2.4 |
| `ms_ssim.py` | MS-SSIM 多尺度底层实现 | 2.4 引用 [11] |
| `standard_metrics.py` | SSIM / PSNR / LPIPS / FID 封装 | 2.4 |

## TPI 公式

$$
\text{TPI} = \frac{R_1 + R_2 + R_3}{3\,\sigma_{base}}
$$

其中 $R(k)=\frac{1}{N}\sum_{x=1}^{N-k}s(x)s(x+k)$ 为垂直投影信号的（有偏）自相关，
$R_1,R_2,R_3$ 为间隔 ≥50 像素的前三个局部极大值，$\sigma_{base}$ 为非峰值区
（峰位 ±10 像素之外）的标准差。TPI 越高，周期规律性越强。

## 快速使用

```python
import cv2
from tpi import compute_tpi
from inter_unit_msssim import inter_unit_ms_ssim

img = cv2.cvtColor(cv2.imread("sample.png"), cv2.COLOR_BGR2RGB)

tpi_canny  = compute_tpi(img, preprocessor="canny")
tpi_line   = compute_tpi(img, preprocessor="lineart")
iu_msssim  = inter_unit_ms_ssim(img, preprocessor="lineart")
print(tpi_canny, tpi_line, iu_msssim)
```

## 命令行

```bash
python tpi.py --pred_dir ../data/generated --out ../results/tpi.csv
python inter_unit_msssim.py --pred_dir ../data/generated --out ../results/inter_unit_msssim.csv
python standard_metrics.py --pred_dir ../data/generated --ref_dir ../data/processed/train --out ../results/standard_metrics.csv
```

## 依赖说明

- `tpi.py`（canny 分支）、`inter_unit_msssim.py`、`standard_metrics.py` 的 SSIM/PSNR
  仅需 numpy / opencv / scikit-image，**CPU 可运行**；
- `lineart` 分支需 `controlnet-aux`；LPIPS / FID 需额外安装对应包。

## 论文参考数值（用于自检）

| 组 | 说明 | TPI |
|---|---|---|
| A | 原生 SD | 2.8 ± 0.6 |
| B | LoRA32 | 3.2 ± 0.7 |
| C | LoRA32 + Canny | 4.3 ± 0.8 |
| D | LoRA8 + Canny | 4.1 ± 0.8 |
| E | LoRA32 + Lineart | 5.2 ± 0.7 |
| H | LoRA8 + Lineart | 5.1 ± 0.7 |

> 复现时若 TPI 绝对值与论文有偏差，优先检查：边缘预处理器是否一致、
> 图像是否统一为 512×512、峰间隔与排除半径是否与 2.4 节一致。

"""
边缘预处理器（Canny / Lineart）
================================
论文 2.4 节：TPI 与条件分支使用"同一个预处理器"来提取边缘图，因此
预处理器的一致性是 TPI 计算的前提。

本模块封装两类预处理器：
  - Canny：传统边缘检测，参数 (low, high, scale)；
  - Lineart：动漫线稿式边缘，本文使用 LineartCoarse 变体，guidance strength 0.8。

依赖 controlnet_aux（Lineart）时可选；若未安装，Lineart 分支将报错提示。
Canny 仅依赖 OpenCV，始终可用。
"""
from __future__ import annotations

import numpy as np
import cv2

# ----------------------------------------------------------------------------
# Canny 预处理器
# ----------------------------------------------------------------------------
# 论文 2.3 节：Canny 默认配置 low=50, high=150, scale=0.7
CANNY_DEFAULT = dict(low=50, high=150, scale=0.7)


def canny_edge(image: np.ndarray,
               low: int = CANNY_DEFAULT["low"],
               high: int = CANNY_DEFAULT["high"],
               scale: float = CANNY_DEFAULT["scale"]) -> np.ndarray:
    """提取 Canny 边缘图。

    参数
    ----
    image : np.ndarray
        输入图像，灰度或 RGB，uint8 / float。
    low, high : int
        Canny 双阈值。
    scale : float
        输出二值图的缩放系数（OpenCV Canny 后按此比例绘制边缘宽度），
        与 ComfyUI 的 Canny 节点语义保持一致。

    返回
    ----
    np.ndarray
        单通道 uint8 边缘图（0 或 255）。
    """
    if image.ndim == 3:
        gray = cv2.cvtColor(_to_uint8(image), cv2.COLOR_RGB2GRAY)
    else:
        gray = _to_uint8(image)

    edges = cv2.Canny(gray, low, high)

    # OpenCV Canny 的 scale 语义：以边缘为种子，用形态学加粗边缘，
    # 复现 ComfyUI Canny 节点中 scale 参数的视觉宽度效果。
    if scale is not None and scale != 1.0:
        kernel = np.ones((3, 3), np.uint8)
        edges = cv2.dilate(edges, kernel, iterations=max(1, int(round(scale * 2))))
    return edges


# ----------------------------------------------------------------------------
# Lineart 预处理器
# ----------------------------------------------------------------------------
# 论文 2.3 节：LineartCoarse，guidance strength 0.8
LINEART_DEFAULT = dict(variant="LineartCoarse", guidance=0.8)


def lineart_edge(image: np.ndarray,
                 variant: str = LINEART_DEFAULT["variant"],
                 device: str = "cuda") -> np.ndarray:
    """提取 Lineart 边缘图（LineartCoarse）。

    依赖 controlnet_aux。若环境未安装，将抛出 ImportError 并给出安装提示。

    返回
    ----
    np.ndarray
        单通道 uint8 边缘图。
    """
    try:
        from controlnet_aux import LineartDetector
        from PIL import Image
    except ImportError as exc:  # pragma: no cover - 依赖缺失时的提示分支
        raise ImportError(
            "Lineart 预处理器需要 controlnet_aux，请先安装：\n"
            "    pip install controlnet-aux==0.0.7"
        ) from exc

    detector_map = {
        "LineartCoarse": LineartDetector,
        "LineartStandard": LineartDetector,
    }
    if variant not in detector_map:
        raise ValueError(f"不支持的 Lineart 变体：{variant}")

    detector = detector_map[variant].from_pretrained("lllyasviel/Annotators")
    detector.to(device)

    # controlnet_aux 接受 PIL 图像
    pil = Image.fromarray(_to_uint8(image) if image.ndim == 3
                          else cv2.cvtColor(_to_uint8(image), cv2.COLOR_GRAY2RGB))
    result = detector(pil, detect_resolution=512, image_resolution=512)
    return np.asarray(result.convert("L"))


# ----------------------------------------------------------------------------
# 统一入口
# ----------------------------------------------------------------------------
def get_edge_map(image: np.ndarray, preprocessor: str = "canny", **kwargs) -> np.ndarray:
    """按名称返回边缘图。

    参数
    ----
    preprocessor : {"canny", "lineart"}
    **kwargs : 透传给具体预处理器。
    """
    p = preprocessor.lower()
    if p == "canny":
        return canny_edge(image, **kwargs)
    if p == "lineart":
        return lineart_edge(image, **kwargs)
    raise ValueError(f"未知预处理器：{preprocessor}（可选 canny / lineart）")


# ----------------------------------------------------------------------------
# 工具函数
# ----------------------------------------------------------------------------
def _to_uint8(image: np.ndarray) -> np.ndarray:
    """将任意取值范围的图像统一转换为 uint8。"""
    if image.dtype == np.uint8:
        return image
    arr = image.astype(np.float32)
    if arr.max() <= 1.0:
        arr = arr * 255.0
    return np.clip(arr, 0, 255).astype(np.uint8)


def binarize(edge: np.ndarray, threshold: int = 0) -> np.ndarray:
    """将边缘图二值化为 {0,1}，供 TPI / 投影使用（论文 2.4：边缘图二值化）。

    threshold=0 表示任何非零像素均视为边缘。
    """
    return (edge > threshold).astype(np.uint8)

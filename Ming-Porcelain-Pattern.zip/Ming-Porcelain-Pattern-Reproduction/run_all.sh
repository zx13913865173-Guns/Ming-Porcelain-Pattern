#!/usr/bin/env bash
# =============================================================================
# 一键复现脚本：指标评估 + 统计分析 + 鲁棒性 + 图件 + 深度分析
# -----------------------------------------------------------------------------
# 适用条件：已将生成图像放入 data/generated/{A..H}/，
#           测试集放入 data/processed/test/，训练集放入 data/processed/train/。
# 说明：LoRA 训练与图像生成依赖 GPU 与 ComfyUI，需按 README 单独执行，
#       不在本脚本内自动运行。
# =============================================================================
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
mkdir -p results figures

echo "==> [1/6] TPI 纹理周期指数"
(cd 04_metrics && python3 tpi.py \
    --pred_dir ../data/generated --out ../results/tpi.csv)

echo "==> [2/6] Inter-unit MS-SSIM"
(cd 04_metrics && python3 inter_unit_msssim.py \
    --pred_dir ../data/generated --out ../results/inter_unit_msssim.csv)

echo "==> [3/6] 标准客观指标（SSIM / PSNR）"
(cd 04_metrics && python3 standard_metrics.py \
    --pred_dir ../data/generated --ref_dir ../data/processed/train \
    --out ../results/standard_metrics.csv)

echo "==> [4/6] 统计分析"
(cd 05_statistics && python3 stats_analysis.py \
    --tpi ../results/tpi.csv \
    --msssim ../results/inter_unit_msssim.csv \
    --out ../results/stats_report.json)

echo "==> [5/6] 鲁棒性测试"
(cd 06_robustness && python3 robustness_test.py \
    --test_dir ../data/processed/test --out ../results/robustness.csv)

echo "==> [6/6] 绘制图件 + PCA"
(cd 07_visualization && python3 plot_figures.py \
    --results ../results --out ../figures)
(cd 08_analysis && python3 pca_analysis.py \
    --train_dir ../data/processed/train --out ../results/pca.json)

echo ""
echo "[全部完成] 结果见 results/，图件见 figures/"

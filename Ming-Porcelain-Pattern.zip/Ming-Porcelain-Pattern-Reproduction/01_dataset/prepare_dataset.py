"""
数据集构建（对应论文 2.1 节）
=============================
职责
----
1. 从原始博物馆图像构建统一数据集：全部归一化为 **512×512 PNG**；
2. 按 **3:1** 随机划分为训练集（120 张）与测试集（40 张），固定随机种子
   （论文使用固定 seed 42 以保证可复现）；
3. 统计四个缠枝纹样变体的类别分布（passionflower lotus / peony /
   chrysanthemum / grape scrolls）。

输入目录约定
------------
    01_dataset/raw/
        ├── passionflower_lotus/*.jpg
        ├── peony/*.jpg
        ├── chrysanthemum/*.jpg
        └── grape_rolls/*.jpg

用法
----
    python prepare_dataset.py --raw_dir raw --out_dir ../data/processed --seed 42
"""
from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import numpy as np

# 论文 2.1 节：四个变体
VARIANTS = ["passionflower_lotus", "peony", "chrysanthemum", "grape_rolls"]

# 论文期望分布（用于核对，非强制）：训练 42/30/26/22，测试 13/10/9/8
EXPECTED_TRAIN = {"passionflower_lotus": 42, "peony": 30,
                  "chrysanthemum": 26, "grape_rolls": 22}
EXPECTED_TEST = {"passionflower_lotus": 13, "peony": 10,
                 "chrysanthemum": 9, "grape_rolls": 8}

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}


def _load_image(path: Path, size: int) -> np.ndarray:
    """读取并归一化到 size×size（默认 512）。"""
    import cv2
    img = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f"无法读取图像：{path}")
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, (size, size), interpolation=cv2.INTER_AREA)
    return img


def build_dataset(raw_dir: str,
                  out_dir: str,
                  size: int = 512,
                  seed: int = 42,
                  test_ratio: float = 0.25) -> dict:
    """构建数据集并返回统计信息。"""
    import cv2

    random.seed(seed)
    np.random.seed(seed)

    raw = Path(raw_dir)
    out = Path(out_dir)
    (out / "train").mkdir(parents=True, exist_ok=True)
    (out / "test").mkdir(parents=True, exist_ok=True)

    stats = {"size": size, "seed": seed, "variants": {},
             "total": {"train": 0, "test": 0}}

    for variant in VARIANTS:
        vdir = raw / variant
        if not vdir.exists():
            print(f"[warn] 缺少类别目录：{vdir}")
            continue

        files = sorted(p for p in vdir.iterdir() if p.suffix.lower() in IMG_EXTS)
        random.shuffle(files)

        n_test = int(round(len(files) * test_ratio))
        test_files = files[:n_test]
        train_files = files[n_test:]

        for split, split_files in (("train", train_files), ("test", test_files)):
            sdir = out / split / variant
            sdir.mkdir(parents=True, exist_ok=True)
            for i, f in enumerate(split_files):
                img = _load_image(f, size)
                # 统一保存为 PNG（论文 2.1）
                out_path = sdir / f"{variant}_{i:04d}.png"
                cv2.imwrite(str(out_path), cv2.cvtColor(img, cv2.COLOR_RGB2BGR))

        stats["variants"][variant] = {"train": len(train_files),
                                      "test": len(test_files),
                                      "total": len(files)}
        stats["total"]["train"] += len(train_files)
        stats["total"]["test"] += len(test_files)
        print(f"[{variant}] 训练 {len(train_files)} / 测试 {len(test_files)}")

    # 保存统计
    stats_path = out / "dataset_stats.json"
    with open(stats_path, "w", encoding="utf-8") as f:
        json.dump(stats, f, ensure_ascii=False, indent=2)

    print(f"\n[ok] 数据集完成：训练 {stats['total']['train']} 张，"
          f"测试 {stats['total']['test']} 张 → {out}")
    print(f"[ok] 统计写入 {stats_path}")
    _compare_expected(stats)
    return stats


def _compare_expected(stats: dict) -> None:
    """与论文期望分布做核对提示。"""
    print("\n分布核对（实际 vs 论文期望）：")
    for split, expected in (("train", EXPECTED_TRAIN), ("test", EXPECTED_TEST)):
        for variant in VARIANTS:
            actual = stats["variants"].get(variant, {}).get(split, 0)
            exp = expected.get(variant, 0)
            flag = "✓" if abs(actual - exp) <= 2 else "≈"
            print(f"  {flag} {split:5s} {variant:22s} 实际 {actual:3d} / 期望 {exp:3d}")


def main() -> None:
    ap = argparse.ArgumentParser(description="构建 512×512 数据集（3:1 划分）")
    ap.add_argument("--raw_dir", required=True, help="原始图像目录（按类别分子目录）")
    ap.add_argument("--out_dir", required=True, help="输出目录")
    ap.add_argument("--size", type=int, default=512)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--test_ratio", type=float, default=0.25)
    args = ap.parse_args()
    build_dataset(args.raw_dir, args.out_dir, args.size, args.seed, args.test_ratio)


if __name__ == "__main__":
    main()

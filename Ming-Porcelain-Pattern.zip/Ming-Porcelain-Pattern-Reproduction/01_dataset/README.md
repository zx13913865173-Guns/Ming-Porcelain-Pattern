# 01_dataset — 数据集构建（论文 2.1 节）

## 数据来源与规模

- 来源：故宫博物院（Palace Museum）与大英博物馆（British Museum）数字馆藏；
- 去重后保留 **100 张**缠枝纹样样本，覆盖四个变体：
  passionflower lotus（西番莲）、peony（牡丹）、chrysanthemum（菊）、grape scrolls（葡萄卷草）；
- 另从同一批公开馆藏补充 **60 张**，扩至 **160 张**；
- 外部验证：Rijksmuseum 馆藏 **20 张**。

## 处理规范

| 项目 | 值 |
|---|---|
| 分辨率 | 512 × 512 |
| 格式 | PNG |
| 归一化工具 | XnConvert（可用 OpenCV 复现） |
| 划分 | 3:1（120 训练 / 40 测试） |
| 随机种子 | 42（固定，保证可复现） |

## 类别分布（论文值）

| 变体 | 训练 | 测试 | 合计 |
|---|---|---|---|
| passionflower lotus | 42 | 13 | 55 |
| peony | 30 | 10 | 40 |
| chrysanthemum | 26 | 9 | 35 |
| grape scrolls | 22 | 8 | 30 |
| **合计** | **120** | **40** | **160** |

## 目录约定

```
01_dataset/raw/
├── passionflower_lotus/
├── peony/
├── chrysanthemum/
└── grape_rolls/
```

## 运行

```bash
python prepare_dataset.py --raw_dir raw --out_dir ../data/processed --seed 42
```

产出：

```
data/processed/
├── train/<variant>/*.png     # 120 张
├── test/<variant>/*.png      # 40 张
└── dataset_stats.json        # 类别分布统计
```

> 注意：原始博物馆图像受机构限制**不可再分发**，本仓库不包含图像数据。
> 生成的图像与派生标注/评分可在论文接收后按需提供。

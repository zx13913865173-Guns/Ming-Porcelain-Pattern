# 08_analysis — 深度分析

本目录包含两个深度分析脚本。

## 1. PCA 内在维度（`pca_analysis.py`，论文 2.4 / 4.2）

- 图像缩放 128×128 并展平，对 120 张训练样本做 PCA；
- 记录保留 **90% 方差**所需的主成分数，100 次 bootstrap 求分布；
- 论文结果：内在维度 ≈ **11.2**，与 rank-8 和 rank-32 的等效性相印证。

```bash
python pca_analysis.py --train_dir ../data/processed/train --out ../results/pca.json
```

## 2. 留一纹样泛化（`leave_one_variant_out.py`，论文 3.5）

- 训练时排除某一纹样变体，在被排除变体上评估 TPI；
- 论文结果：排除 grape 后，留出的 grape 测试图仍得 TPI = **4.5 ± 0.8**。

| 变体 | TPI | n |
|---|---|---|
| passionflower lotus | 5.3 ± 0.6 | 13 |
| peony | 5.1 ± 0.6 | 10 |
| chrysanthemum | 5.0 ± 0.7 | 9 |
| grape（留出） | 4.5 ± 0.8 | 8 |
| mixed | 5.1 ± 0.7 | 40 |

```bash
python leave_one_variant_out.py --gen_root ../data/generated/lovo --out ../results/lovo.csv
```

> 每折的重训请配合 `configs/lora_train_rank8.yaml`（调整 `train_dir` 排除对应变体）完成；
> 本脚本负责评估与汇总。

"""
PCA 内在维度分析（对应论文 2.4 节）
====================================
将图像缩放为 128×128 并展平，对 120 张训练样本做主成分分析（scikit-learn），
记录保留 90% 方差所需的主成分数，并在 100 次 bootstrap 上求其分布。

论文结果：内在维度 ≈ **11.2**，与 rank-8 / rank-32 的等效性相印证——
任务特定更新位于低维子空间。

用法
----
    python pca_analysis.py --train_dir ../data/processed/train --out ../results/pca.json
"""
from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import numpy as np


def _iter_images(root: Path):
    exts = {".png", ".jpg", ".jpeg", ".bmp"}
    return sorted(p for p in root.rglob("*") if p.suffix.lower() in exts)


def load_flat(root: str, size: int = 128) -> np.ndarray:
    import cv2
    feats = []
    for p in _iter_images(Path(root)):
        img = cv2.imread(str(p), cv2.IMREAD_GRAYSCALE)
        if img is None:
            continue
        img = cv2.resize(img, (size, size), interpolation=cv2.INTER_AREA)
        feats.append(img.flatten().astype(np.float32) / 255.0)
    if not feats:
        raise FileNotFoundError(f"无图像：{root}")
    return np.stack(feats)


def components_for_variance(X: np.ndarray, target: float = 0.90) -> int:
    from sklearn.decomposition import PCA
    pca = PCA(n_components=min(X.shape) - 1, random_state=42)
    pca.fit(X)
    cum = np.cumsum(pca.explained_variance_ratio_)
    return int(np.searchsorted(cum, target) + 1)


def run(train_dir: str, out_path: str, size: int = 128,
        n_bootstrap: int = 100) -> dict:
    X = load_flat(train_dir, size)
    n = X.shape[0]

    base_dim = components_for_variance(X, 0.90)

    random.seed(42)
    np.random.seed(42)
    dims = []
    for _ in range(n_bootstrap):
        idx = np.random.choice(n, n, replace=True)
        try:
            dims.append(components_for_variance(X[idx], 0.90))
        except Exception:
            continue

    report = {
        "n_samples": n,
        "feature_dim": int(X.shape[1]),
        "pca_90pct_components": base_dim,
        "bootstrap_mean": float(np.mean(dims)),
        "bootstrap_sd": float(np.std(dims, ddof=1)) if len(dims) > 1 else 0.0,
        "n_bootstrap": len(dims),
        "paper_reference": 11.2,
    }
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(f"[ok] PCA 报告 → {out_path}")
    print(f"    内在维度（保留90%方差）≈ {report['bootstrap_mean']:.1f} "
          f"± {report['bootstrap_sd']:.1f}（论文参考 11.2）")
    return report


def main() -> None:
    ap = argparse.ArgumentParser(description="PCA 内在维度分析")
    ap.add_argument("--train_dir", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--size", type=int, default=128)
    ap.add_argument("--bootstrap", type=int, default=100)
    args = ap.parse_args()
    run(args.train_dir, args.out, args.size, args.bootstrap)


if __name__ == "__main__":
    main()

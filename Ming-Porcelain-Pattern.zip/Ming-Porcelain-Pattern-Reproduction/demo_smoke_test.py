"""
端到端冒烟测试（CPU 可运行）
============================
在没有 GPU / ComfyUI / 真实数据的情况下，用**合成周期纹样**验证核心算法链路：
  1. 生成横向带状的周期重复纹样（模拟缠枝纹单元）；
  2. 计算 TPI（canny 分支）；
  3. 计算 Inter-unit MS-SSIM；
  4. 运行统计分析链路；
  5. 运行 PCA 内在维度估计。

断言：TPI 在"周期规整"图上应显著高于"周期被打断"的图；
      统计与 PCA 链路应可正常运行。

用法
----
    python demo_smoke_test.py
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "04_metrics"))
sys.path.insert(0, str(HERE / "05_statistics"))
sys.path.insert(0, str(HERE / "08_analysis"))


def make_periodic_pattern(size: int = 512, unit: int = 96,
                          periodic: bool = True, seed: int = 0,
                          noise_sigma: float = 3.0) -> np.ndarray:
    """合成横向带状纹样：沿 x 方向重复 unit 宽度的花瓣单元。"""
    rng = np.random.default_rng(seed)
    img = np.full((size, size), 255, dtype=np.uint8)
    yy, xx = np.mgrid[0:size, 0:size]

    n_units = size // unit
    for i in range(n_units):
        cx = i * unit + unit // 2
        cy = size // 2
        r = unit // 3
        if not periodic and i % 3 == 1:
            cx += unit // 4                      # 人为破坏周期：位移
            r = unit // 4                        # 并改变单元尺寸
        mask = (xx - cx) ** 2 + (yy - cy) ** 2 <= r ** 2
        img[mask] = 40
        # 花瓣式卷曲
        for k in range(6):
            ang = k * np.pi / 3
            px = int(cx + r * 0.9 * np.cos(ang))
            py = int(cy + r * 0.9 * np.sin(ang))
            sub = (xx - px) ** 2 + (yy - py) ** 2 <= (r // 3) ** 2
            img[sub] = 60

    # 轻微噪声，使边缘更自然
    noise = rng.normal(0, 3, img.shape)
    img = np.clip(img.astype(np.float64) + noise, 0, 255).astype(np.uint8)
    return np.stack([img] * 3, axis=-1)


def main() -> None:
    print("=" * 60)
    print("端到端冒烟测试（CPU）")
    print("=" * 60)

    from tpi import compute_tpi
    from inter_unit_msssim import inter_unit_ms_ssim
    from stats_analysis import cohens_d, tost_independent, spearman_with_ci, bh_correction

    # ---- 1. 合成数据 ----
    periodic_img = make_periodic_pattern(periodic=True, seed=1)
    broken_img = make_periodic_pattern(periodic=False, seed=1)

    # ---- 2. TPI ----
    tpi_p = compute_tpi(periodic_img, preprocessor="canny")
    tpi_b = compute_tpi(broken_img, preprocessor="canny")
    print(f"\n[TPI] 周期规整图 = {tpi_p:.3f}")
    print(f"[TPI] 周期打断图 = {tpi_b:.3f}")
    assert tpi_p > tpi_b, "TPI 未能区分周期规整/被打断的图"
    print("[PASS] TPI 对周期破坏敏感 ✓")

    # ---- 3. Inter-unit MS-SSIM ----
    iu_p = inter_unit_ms_ssim(periodic_img, preprocessor="canny", use_sift=False)
    iu_b = inter_unit_ms_ssim(broken_img, preprocessor="canny", use_sift=False)
    print(f"\n[IU-MS-SSIM] 周期规整图 = {iu_p}")
    print(f"[IU-MS-SSIM] 周期打断图 = {iu_b}")
    assert iu_p is not None and iu_p >= (iu_b or 0), "Inter-unit MS-SSIM 未反映单元一致性"
    print("[PASS] Inter-unit MS-SSIM 计算正常 ✓")

    # ---- 4. 统计链路 ----
    print("\n[统计] 抽样模拟 Group E vs H 的 TPI：")
    e = np.random.default_rng(0).normal(5.2, 0.7, 40)
    h = np.random.default_rng(1).normal(5.1, 0.7, 40)
    d = cohens_d(h, e)
    tost = tost_independent(h, e, bound=0.5)
    rho = spearman_with_ci(e, h)
    bh = bh_correction([0.01, 0.04, 0.03, 0.20])
    print(f"  Cohen's d = {d:.3f}")
    print(f"  TOST(±0.5) p = {tost['p']:.4f}")
    print(f"  Spearman ρ = {rho['rho']:.3f} (95% CI {rho['ci95']})")
    print(f"  BH 校正后 = {['%.3f' % p for p in bh['p_adj']]}")
    print("[PASS] 统计链路正常 ✓")

    # ---- 5. PCA ----
    print("\n[PCA] 合成 120 张训练样本估计内在维度：")
    from pca_analysis import components_for_variance
    import cv2
    feats = []
    for i in range(120):
        # 样本差异仅由「单元宽度 + 相位」两个自由度驱动，构成低维流形
        unit = [64, 80, 96, 112, 128][i % 5]
        im = make_periodic_pattern(256, unit, True, seed=0, noise_sigma=0.0)
        im = np.roll(im, (i * 7) % unit, axis=1)
        g = cv2.cvtColor(im, cv2.COLOR_RGB2GRAY).astype(np.float32) / 255.0
        g = cv2.resize(g, (128, 128), interpolation=cv2.INTER_AREA)
        feats.append(g.flatten())
    X = np.stack(feats)
    dim = components_for_variance(X, 0.90)
    print(f"  90% 方差所需主成分 = {dim}（真实数据下论文报告 ≈ 11.2）")
    print("[PASS] PCA 链路正常 ✓")

    print("\n" + "=" * 60)
    print("全部冒烟测试通过 ✓")
    print("=" * 60)


if __name__ == "__main__":
    main()

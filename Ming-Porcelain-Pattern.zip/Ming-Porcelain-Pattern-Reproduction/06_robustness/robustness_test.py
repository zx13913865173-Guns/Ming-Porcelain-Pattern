"""
指标鲁棒性测试（对应论文 3.6 节）
==================================
在受控退化条件下检验 TPI 的稳定性，并验证 `Lineart > Canny` 的相对排序是否保持：

- 高斯噪声：σ = 5, 10, 15；
- JPEG 压缩：质量 80, 60, 40；
- 下采样：256×256、128×128。

论文结论：TPI 相对变化分别 < 8%、< 6%、< 5%，且 Lineart > Canny 始终成立。

用法
----
    python robustness_test.py --test_dir ../data/processed/test --out ../results/robustness.csv
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np


def relative_tpi_change(base: np.ndarray, degraded: np.ndarray) -> float:
    """计算 TPI 的相对变化（%）。"""
    base_mean = np.mean(base)
    if base_mean == 0:
        return 0.0
    return float(abs(np.mean(degraded) - base_mean) / base_mean * 100.0)


def _iter_images(root: Path):
    exts = {".png", ".jpg", ".jpeg", ".bmp"}
    return sorted(p for p in root.rglob("*") if p.suffix.lower() in exts)


# ----------------------------------------------------------------------------
# 退化算子
# ----------------------------------------------------------------------------
def add_gaussian_noise(img: np.ndarray, sigma: float) -> np.ndarray:
    noise = np.random.normal(0, sigma, img.shape)
    return np.clip(img.astype(np.float64) + noise, 0, 255).astype(np.uint8)


def jpeg_compress(img: np.ndarray, quality: int) -> np.ndarray:
    import cv2
    ok, enc = cv2.imencode(".jpg", cv2.cvtColor(img, cv2.COLOR_RGB2BGR),
                           [int(cv2.IMWRITE_JPEG_QUALITY), quality])
    if not ok:
        raise RuntimeError("JPEG 编码失败")
    dec = cv2.imdecode(enc, cv2.IMREAD_COLOR)
    return cv2.cvtColor(dec, cv2.COLOR_BGR2RGB)


def downsample(img: np.ndarray, size: int) -> np.ndarray:
    import cv2
    small = cv2.resize(img, (size, size), interpolation=cv2.INTER_AREA)
    return cv2.resize(small, (img.shape[1], img.shape[0]),
                      interpolation=cv2.INTER_NEAREST)


# ----------------------------------------------------------------------------
# 主流程
# ----------------------------------------------------------------------------
def run(test_dir: str, out_csv: str, preprocessors=("canny", "lineart")) -> None:
    import cv2

    try:
        from tpi import compute_tpi
    except ImportError:
        import sys
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "04_metrics"))
        from tpi import compute_tpi

    images = [cv2.cvtColor(cv2.imread(str(p), cv2.IMREAD_COLOR),
                           cv2.COLOR_BGR2RGB)
              for p in _iter_images(Path(test_dir))]
    if not images:
        raise FileNotFoundError(f"测试目录无图像：{test_dir}")

    # 过滤掉当前环境不可用的预处理器（如未安装 controlnet_aux 时的 lineart）
    available = []
    for pre in preprocessors:
        try:
            compute_tpi(images[0], preprocessor=pre)
            available.append(pre)
        except Exception as exc:
            print(f"[warn] 预处理器 {pre} 不可用，已跳过：{exc}")
    if not available:
        raise RuntimeError("没有可用的边缘预处理器")
    preprocessors = tuple(available)

    # 每种预处理器的基准 TPI
    baseline = {pre: np.array([compute_tpi(im, preprocessor=pre) for im in images])
                for pre in preprocessors}

    rows = []
    # 高斯噪声
    for sigma in (5, 10, 15):
        deg = [add_gaussian_noise(im, sigma) for im in images]
        row = {"condition": "gaussian_noise", "level": f"sigma={sigma}"}
        for pre in preprocessors:
            vals = np.array([compute_tpi(im, preprocessor=pre) for im in deg])
            row[f"tpi_{pre}"] = round(float(vals.mean()), 4)
            row[f"delta_{pre}_pct"] = round(relative_tpi_change(baseline[pre], vals), 2)
        rows.append(row)

    # JPEG
    for q in (80, 60, 40):
        deg = [jpeg_compress(im, q) for im in images]
        row = {"condition": "jpeg", "level": f"quality={q}"}
        for pre in preprocessors:
            vals = np.array([compute_tpi(im, preprocessor=pre) for im in deg])
            row[f"tpi_{pre}"] = round(float(vals.mean()), 4)
            row[f"delta_{pre}_pct"] = round(relative_tpi_change(baseline[pre], vals), 2)
        rows.append(row)

    # 下采样
    for size in (256, 128):
        deg = [downsample(im, size) for im in images]
        row = {"condition": "downsample", "level": f"{size}px"}
        for pre in preprocessors:
            vals = np.array([compute_tpi(im, preprocessor=pre) for im in deg])
            row[f"tpi_{pre}"] = round(float(vals.mean()), 4)
            row[f"delta_{pre}_pct"] = round(relative_tpi_change(baseline[pre], vals), 2)
        rows.append(row)

    Path(out_csv).parent.mkdir(parents=True, exist_ok=True)
    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"[ok] 鲁棒性结果 → {out_csv}")


def main() -> None:
    ap = argparse.ArgumentParser(description="TPI 鲁棒性测试")
    ap.add_argument("--test_dir", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    run(args.test_dir, args.out)


if __name__ == "__main__":
    main()

# 06_robustness — 指标鲁棒性（论文 3.6 节）

## 测试条件

| 退化类型 | 水平 |
|---|---|
| 高斯噪声 | σ = 5, 10, 15 |
| JPEG 压缩 | 质量 80, 60, 40 |
| 下采样 | 256 × 256、128 × 128 |

## 论文结论（自检参考）

- 高斯噪声、JPEG、下采样下，TPI 相对变化分别 **< 8%、< 6%、< 5%**；
- `Lineart > Canny` 的相对排序在所有退化条件下均保持。

## 运行

```bash
python robustness_test.py --test_dir ../data/processed/test --out ../results/robustness.csv
```

产出 `results/robustness.csv`：每行一个退化条件，列出各预处理器的 TPI 均值与相对变化%。 

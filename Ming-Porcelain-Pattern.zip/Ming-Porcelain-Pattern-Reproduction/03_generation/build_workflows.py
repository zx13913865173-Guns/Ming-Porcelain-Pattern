"""
ComfyUI 工作流生成（对应论文 2.3 节）
====================================
根据 `configs/generation_groups.yaml` 为 A–H 八个实验组生成 ComfyUI
（API 格式）工作流 JSON，供 generate_groups.py 提交给 ComfyUI 执行。

每组差异体现在：
  - 是否加载 LoRA 及 rank（lora_rank8 / lora_rank32）；
  - 是否接入 ControlNet 及类型（canny / lineart / all_white）；
  - ControlNet 参数（Canny 阈值、Lineart 引导强度等）。

用法
----
    python build_workflows.py --config ../configs/generation_groups.yaml --out_dir workflows
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import yaml


def _load(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def build_workflow(group_name: str, group: dict, g: dict, cn_models: dict) -> dict:
    """构造一个 ComfyUI API 格式工作流（节点 id -> {class_type, inputs}）。"""
    nodes: dict[str, dict] = {}
    idx = 1

    # 1) 载入 checkpoint
    nodes[str(idx)] = {
        "class_type": "CheckpointLoaderSimple",
        "inputs": {"ckpt_name": g["checkpoint"]},
    }
    model_ref = [str(idx), 0]
    clip_ref = [str(idx), 1]
    idx += 1

    # 2) 可选 LoRA
    if group.get("lora"):
        nodes[str(idx)] = {
            "class_type": "LoraLoader",
            "inputs": {
                "model": model_ref,
                "clip": clip_ref,
                "lora_name": f"{group['lora']}.safetensors",
                "strength_model": 1.0,
                "strength_clip": 1.0,
            },
        }
        model_ref = [str(idx), 0]
        clip_ref = [str(idx), 1]
        idx += 1

    # 3) 正 / 负提示词
    pos_id, neg_id = str(idx), str(idx + 1)
    nodes[pos_id] = {
        "class_type": "CLIPTextEncode",
        "inputs": {"text": g["prompt_template"], "clip": clip_ref},
    }
    nodes[neg_id] = {
        "class_type": "CLIPTextEncode",
        "inputs": {"text": g["negative_prompt"], "clip": clip_ref},
    }
    idx += 2
    positive_ref = [pos_id, 0]
    negative_ref = [neg_id, 0]

    # 4) 可选 ControlNet 分支
    cn = group.get("controlnet")
    if cn:
        params = group.get("controlnet_params", {})

        # 4a) 载入控制图（占位输入，运行时替换为数据集中的图）
        img_id = str(idx)
        nodes[img_id] = {
            "class_type": "LoadImage",
            "inputs": {"image": "placeholder.png"},
        }
        idx += 1
        control_image_ref = [img_id, 0]

        # 4b) 预处理 / 全白对照
        if cn == "canny":
            pre_id = str(idx)
            nodes[pre_id] = {
                "class_type": "CannyEdgePreprocessor",
                "inputs": {
                    "image": control_image_ref,
                    "low_threshold": params.get("low", 50),
                    "high_threshold": params.get("high", 150),
                    "resolution": g["resolution"],
                },
            }
            idx += 1
            control_image_ref = [pre_id, 0]
            cn_model = cn_models["canny"]
        elif cn == "lineart":
            pre_id = str(idx)
            nodes[pre_id] = {
                "class_type": "LineartPreprocessor",
                "inputs": {
                    "image": control_image_ref,
                    "coarse": params.get("variant", "LineartCoarse") == "LineartCoarse",
                    "resolution": g["resolution"],
                },
            }
            idx += 1
            control_image_ref = [pre_id, 0]
            cn_model = cn_models["lineart"]
        elif cn == "all_white":
            pre_id = str(idx)
            nodes[pre_id] = {
                "class_type": "EmptyImage",
                "inputs": {"width": g["resolution"], "height": g["resolution"],
                           "batch_size": 1},
            }
            idx += 1
            control_image_ref = [pre_id, 0]
            cn_model = cn_models["canny"]
        else:
            raise ValueError(f"未知 ControlNet 类型：{cn}")

        # 4c) 载入 ControlNet 并应用
        cn_id = str(idx)
        nodes[cn_id] = {
            "class_type": "ControlNetLoader",
            "inputs": {"control_net_name": cn_model},
        }
        idx += 1

        apply_id = str(idx)
        nodes[apply_id] = {
            "class_type": "ControlNetApplyAdvanced",
            "inputs": {
                "positive": positive_ref,
                "negative": negative_ref,
                "control_net": [cn_id, 0],
                "image": control_image_ref,
                "strength": params.get("strength", params.get("scale", 0.7)),
                "start_percent": 0.0,
                "end_percent": 1.0,
            },
        }
        idx += 1
        positive_ref = [apply_id, 0]
        negative_ref = [apply_id, 1]

    # 5) 空 latent
    latent_id = str(idx)
    nodes[latent_id] = {
        "class_type": "EmptyLatentImage",
        "inputs": {"width": g["resolution"], "height": g["resolution"],
                   "batch_size": 1},
    }
    idx += 1

    # 6) 采样器
    sampler_id = str(idx)
    nodes[sampler_id] = {
        "class_type": "KSampler",
        "inputs": {
            "model": model_ref,
            "positive": positive_ref,
            "negative": negative_ref,
            "latent_image": [latent_id, 0],
            "seed": g["seed"],
            "steps": g["steps"],
            "cfg": g["cfg_scale"],
            "sampler_name": g["sampler"],
            "scheduler": "karras",
            "denoise": 1.0,
        },
    }
    idx += 1

    # 7) 解码 + 保存
    vae_id = str(idx)
    nodes[vae_id] = {
        "class_type": "VAEDecode",
        "inputs": {"samples": [sampler_id, 0], "vae": ["1", 2]},
    }
    idx += 1
    save_id = str(idx)
    nodes[save_id] = {
        "class_type": "SaveImage",
        "inputs": {"images": [vae_id, 0],
                   "filename_prefix": f"MingPattern_{group_name}"},
    }

    return nodes


def main() -> None:
    ap = argparse.ArgumentParser(description="生成 A–H 组 ComfyUI 工作流")
    ap.add_argument("--config", required=True)
    ap.add_argument("--out_dir", required=True)
    args = ap.parse_args()

    cfg = _load(args.config)
    g = cfg["global"]
    cn_models = cfg["controlnet_models"]
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    for name, group in cfg["groups"].items():
        wf = build_workflow(name, group, g, cn_models)
        path = out / f"{name}_{group.get('controlnet') or 'baseline'}.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(wf, f, ensure_ascii=False, indent=2)
        print(f"[ok] 组 {name}: {group['desc']} → {path.name}")

    # 引导强度消融工作流
    ab = cfg.get("guidance_ablation")
    if ab:
        base_group = cfg["groups"][ab["group"]].copy()
        for s in ab["strengths"]:
            base_group["controlnet_params"] = {"variant": "LineartCoarse", "strength": s}
            wf = build_workflow(f"{ab['group']}_s{s}", base_group, g, cn_models)
            path = out / f"ablation_{ab['group']}_strength{s}.json"
            with open(path, "w", encoding="utf-8") as f:
                json.dump(wf, f, ensure_ascii=False, indent=2)
            print(f"[ok] 消融 强度 {s} → {path.name}")

    print(f"\n[ok] 全部工作流已写入 {out}")


if __name__ == "__main__":
    main()

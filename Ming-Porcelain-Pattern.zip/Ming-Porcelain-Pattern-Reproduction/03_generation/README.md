# 03_generation — 图像生成（论文 2.3 节）

## 统一生成参数

| 参数 | 值 |
|---|---|
| 采样器 | DPM++ 2M Karras |
| 推理步数 | 30 |
| CFG scale | 7.5 |
| 分辨率 | 512 × 512 |
| 每组张数 | 40（A–H 共 320 张） |

## A–H 八个实验组

| 组 | 配置 | 论文角色 |
|---|---|---|
| A | 原生 Stable Diffusion | 客观基线 |
| B | 仅 LoRA rank 32 | 单组件消融 |
| C | LoRA rank 32 + Canny（50/150，scale 0.7） | 边缘对比 |
| D | LoRA rank 8 + Canny | 边缘对比 |
| E | LoRA rank 32 + Lineart（LineartCoarse，0.8） | 完整配置 |
| F | LoRA rank 32 + 全白控制图（scale 0.7） | 空白对照 |
| G | 无 LoRA + 仅 Lineart（0.8） | 单组件消融 |
| H | **LoRA rank 8 + Lineart（0.8）** | **最优配置** |

引导强度消融在 Group H 上进行：strength ∈ {0.5, 0.6, 0.7, 0.8, 0.9, 1.0}，
每档 20 张（共 120 张），独立于 320 张主实验图。**0.8** 由 TPI 与 ICH 周期评分的
联合峰值选出。

## 运行

```bash
# 1) 生成全部工作流 JSON
python build_workflows.py --config ../configs/generation_groups.yaml --out_dir workflows

# 2) 启动 ComfyUI（另开终端）后批量生成
python generate_groups.py --workflow_dir workflows --out_dir ../data/generated
```

产出：`data/generated/{A..H}/*.png`。

## 依赖

- 运行中的 ComfyUI 服务（默认 `http://127.0.0.1:8188`）；
- ComfyUI 扩展：`comfyui_controlnet_aux`（提供 Canny / Lineart 预处理节点）；
- 模型权重：`v1-5-pruned-emaonly.safetensors`、
  `control_v11p_sd15_canny.pth`、`control_v11p_sd15_lineart.pth`、
  `lora_rank8.safetensors`、`lora_rank32.safetensors`。

> 脚本采用 ComfyUI 的 API 格式工作流（节点 id → {class_type, inputs}），
> 可直接经 `/prompt` 接口提交，便于批量自动化。

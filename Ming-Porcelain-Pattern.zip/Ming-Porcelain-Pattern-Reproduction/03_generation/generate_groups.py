"""
批量图像生成（对应论文 2.3 节）
===============================
将 build_workflows.py 生成的工作流通过 ComfyUI HTTP API 批量提交，
从输出目录收集生成的图像。

约定
----
- ComfyUI 服务地址：默认 http://127.0.0.1:8188
- 每组生成 40 张，共 320 张（A–H）；引导强度消融另生成 120 张。

用法
----
    python generate_groups.py --workflow_dir workflows --out_dir ../data/generated
"""
from __future__ import annotations

import argparse
import json
import time
import uuid
from pathlib import Path

import requests


COMFY_HOST = "http://127.0.0.1:8188"


def queue_prompt(workflow: dict, client_id: str) -> str:
    """提交工作流，返回 prompt_id。"""
    payload = {"prompt": workflow, "client_id": client_id}
    resp = requests.post(f"{COMFY_HOST}/prompt", json=payload, timeout=30)
    resp.raise_for_status()
    return resp.json()["prompt_id"]


def wait_for_result(prompt_id: str, timeout: int = 300) -> dict:
    """轮询直到该 prompt 完成，返回 history 记录。"""
    start = time.time()
    while time.time() - start < timeout:
        resp = requests.get(f"{COMFY_HOST}/history/{prompt_id}", timeout=30)
        if resp.status_code == 200:
            history = resp.json()
            if prompt_id in history:
                return history[prompt_id]
        time.sleep(2)
    raise TimeoutError(f"prompt {prompt_id} 超时未完成")


def collect_images(result: dict, out_dir: Path, group: str) -> int:
    """把 history 中的输出图像复制到 out_dir/<group>/。"""
    saved = 0
    out_dir.mkdir(parents=True, exist_ok=True)
    for node_output in result.get("outputs", {}).values():
        for img in node_output.get("images", []):
            data = requests.get(
                f"{COMFY_HOST}/view",
                params={"filename": img["filename"],
                        "subfolder": img.get("subfolder", ""),
                        "type": img.get("type", "output")},
                timeout=30).content
            (out_dir / img["filename"]).write_bytes(data)
            saved += 1
    return saved


def main() -> None:
    ap = argparse.ArgumentParser(description="批量提交 ComfyUI 工作流并收集图像")
    ap.add_argument("--workflow_dir", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--repeats", type=int, default=40,
                    help="每组生成张数（论文为 40）")
    args = ap.parse_args()

    client_id = str(uuid.uuid4())
    wf_dir = Path(args.workflow_dir)
    out_root = Path(args.out_dir)

    for wf_path in sorted(wf_dir.glob("*.json")):
        group = wf_path.stem
        print(f"\n=== 组 {group} ===")
        workflow = json.loads(wf_path.read_text(encoding="utf-8"))

        for i in range(args.repeats):
            # 逐张改变 seed，其余参数固定（同组内 seed 起点一致）
            for node in workflow.values():
                if node.get("class_type") == "KSampler":
                    node["inputs"]["seed"] = 42 + i
            pid = queue_prompt(workflow, client_id)
            result = wait_for_result(pid)
            n = collect_images(result, out_root / group, group)
            print(f"  [{i + 1}/{args.repeats}] 保存 {n} 张")

    print(f"\n[ok] 生成完成 → {out_root}")


if __name__ == "__main__":
    main()

"""
统计分析（对应论文 2.5 节）
============================
在指标结果与专家评分之上完成论文的全部统计推断：

- 单因素方差分析（One-way ANOVA）+ Tukey HSD：比较 A–E、H 组的客观指标；
- 配对 t 检验：比较预处理（Lineart vs Canny）；
- 独立样本 t 检验 + **TOST 等价检验**：比较 Group H 与 Group E
  （边界 ±0.5 TPI、±0.03 Inter-unit MS-SSIM、±0.3 主观周期评分）；
- TPI TOST 敏感性分析：边界 ±0.3 / ±0.5 / ±0.7；
- Spearman 相关：专家评分与指标之间的关系；
- Cohen's d 效应量；
- Benjamini–Hochberg 多重比较校正（α = 0.05）。

用法
----
    python stats_analysis.py --tpi ../results/tpi.csv \
                             --msssim ../results/inter_unit_msssim.csv \
                             --out ../results/stats_report.json
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd
from scipy import stats


# ----------------------------------------------------------------------------
# 基础统计量
# ----------------------------------------------------------------------------
def cohens_d(a: Sequence[float], b: Sequence[float]) -> float:
    """Cohen's d，SD_pooled = √((SD_a² + SD_b²)/2)（论文 2.5 节）。"""
    a, b = np.asarray(a, float), np.asarray(b, float)
    sd_pooled = np.sqrt((a.var(ddof=1) + b.var(ddof=1)) / 2.0)
    if sd_pooled == 0:
        return 0.0
    return float((a.mean() - b.mean()) / sd_pooled)


def tost_independent(a: Sequence[float], b: Sequence[float],
                     bound: float) -> dict:
    """独立样本 TOST 等价检验：H0 为 |μ_a − μ_b| ≥ bound。"""
    a, b = np.asarray(a, float), np.asarray(b, float)
    na, nb = len(a), len(b)
    diff = a.mean() - b.mean()
    se = np.sqrt(a.var(ddof=1) / na + b.var(ddof=1) / nb)
    df = na + nb - 2
    t_lo = (diff + bound) / se      # 下界单侧
    t_hi = (diff - bound) / se      # 上界单侧
    p_lo = 1 - stats.t.cdf(t_lo, df)
    p_hi = stats.t.cdf(t_hi, df)
    return {"diff": float(diff), "se": float(se), "df": df,
            "p": float(max(p_lo, p_hi)), "bound": bound}


def tost_paired(a: Sequence[float], b: Sequence[float], bound: float) -> dict:
    """配对 TOST：a 与 b 为同一批样本的两种条件。"""
    a, b = np.asarray(a, float), np.asarray(b, float)
    d = a - b
    n = len(d)
    mean_d = d.mean()
    se = d.std(ddof=1) / np.sqrt(n)
    df = n - 1
    t_lo = (mean_d + bound) / se
    t_hi = (mean_d - bound) / se
    p_lo = 1 - stats.t.cdf(t_lo, df)
    p_hi = stats.t.cdf(t_hi, df)
    return {"diff": float(mean_d), "se": float(se), "df": df,
            "p": float(max(p_lo, p_hi)), "bound": bound}


def spearman_with_ci(x: Sequence[float], y: Sequence[float]) -> dict:
    """Spearman 相关 + Fisher z 置信区间（论文 2.5 节）。"""
    x, y = np.asarray(x, float), np.asarray(y, float)
    rho, p = stats.spearmanr(x, y)
    n = len(x)
    # Fisher z 变换
    z = np.arctanh(rho)
    se = 1.0 / np.sqrt(n - 3)
    lo, hi = np.tanh(z - 1.96 * se), np.tanh(z + 1.96 * se)
    return {"rho": float(rho), "p": float(p), "n": n,
            "fisher_z": float(z), "se": float(se),
            "ci95": [float(lo), float(hi)], "z_over_se": float(z / se)}


def anova_tukey(groups: dict[str, Sequence[float]]) -> dict:
    """单因素 ANOVA + Tukey HSD。"""
    from statsmodels.stats.multicomp import pairwise_tukeyhsd

    keys = list(groups.keys())
    values = [np.asarray(groups[k], float) for k in keys]
    f_stat, p = stats.f_oneway(*values)

    all_vals = np.concatenate(values)
    labels = np.concatenate([[k] * len(v) for k, v in zip(keys, values)])
    tukey = pairwise_tukeyhsd(all_vals, labels, alpha=0.05)

    comparisons = []
    for row in tukey.summary().data[1:]:
        comparisons.append({"group1": row[0], "group2": row[1],
                            "meandiff": float(row[2]), "p_adj": float(row[3]),
                            "reject": bool(row[6])})
    return {"F": float(f_stat), "p": float(p), "tukey": comparisons}


def bh_correction(pvals: Sequence[float], alpha: float = 0.05) -> dict:
    """Benjamini–Hochberg 校正。"""
    from statsmodels.stats.multitest import multipletests
    reject, p_adj, _, _ = multipletests(pvals, alpha=alpha, method="fdr_bh")
    return {"reject": [bool(r) for r in reject],
            "p_adj": [float(p) for p in p_adj]}


# ----------------------------------------------------------------------------
# 主分析
# ----------------------------------------------------------------------------
def run_analysis(tpi_csv: str, msssim_csv: str | None,
                 ratings_csv: str | None, out_path: str) -> dict:
    report: dict = {}

    # ---- TPI：按组聚合 ----
    tpi_df = pd.read_csv(tpi_csv)
    tpi_col = "tpi_canny" if "tpi_canny" in tpi_df.columns else tpi_df.columns[-1]
    tpi_groups = {g: sub[tpi_col].dropna().tolist()
                  for g, sub in tpi_df.groupby("group")}
    report["tpi_group_means"] = {g: {"mean": float(np.mean(v)),
                                     "sd": float(np.std(v, ddof=1)),
                                     "n": len(v)}
                                 for g, v in tpi_groups.items() if v}

    # ANOVA + Tukey（A–E, H）
    subset = {g: v for g, v in tpi_groups.items()
              if g in {"A", "B", "C", "D", "E", "H"} and len(v) > 1}
    if len(subset) >= 2:
        report["tpi_anova"] = anova_tukey(subset)

    # 配对比较：Lineart vs Canny（同组内，用 lineart 列与 canny 列）
    if "tpi_canny" in tpi_df.columns and "tpi_lineart" in tpi_df.columns:
        paired = []
        for g, sub in tpi_df.groupby("group"):
            a, b = sub["tpi_lineart"].dropna(), sub["tpi_canny"].dropna()
            m = min(len(a), len(b))
            if m > 1:
                t, p = stats.ttest_rel(a[:m], b[:m])
                paired.append({"group": g, "t": float(t), "p": float(p),
                               "mean_lineart": float(a[:m].mean()),
                               "mean_canny": float(b[:m].mean())})
        report["lineart_vs_canny_paired"] = paired

    # TOST：Group H vs Group E（独立样本）
    if "E" in tpi_groups and "H" in tpi_groups:
        e, h = tpi_groups["E"], tpi_groups["H"]
        t_stat, p_val = stats.ttest_ind(h, e)
        report["tpi_H_vs_E"] = {
            "t": float(t_stat), "p": float(p_val), "cohens_d": cohens_d(h, e),
        }
        report["tpi_tost"] = {f"bound_{b}": tost_independent(h, e, b)
                              for b in (0.3, 0.5, 0.7)}

    # ---- Inter-unit MS-SSIM ----
    if msssim_csv and Path(msssim_csv).exists():
        df = pd.read_csv(msssim_csv)
        col = "inter_unit_msssim"
        grp = {g: sub[col].dropna().tolist() for g, sub in df.groupby("group")}
        report["msssim_group_means"] = {g: {"mean": float(np.mean(v)),
                                            "sd": float(np.std(v, ddof=1)),
                                            "n": len(v)}
                                        for g, v in grp.items() if v}
        if "E" in grp and "H" in grp and len(grp["E"]) > 1 and len(grp["H"]) > 1:
            report["msssim_tost"] = tost_independent(grp["H"], grp["E"], 0.03)

    # ---- 专家评分相关性 ----
    if ratings_csv and Path(ratings_csv).exists():
        r = pd.read_csv(ratings_csv)
        if {"tpi", "expert_periodicity"}.issubset(r.columns):
            report["tpi_vs_expert_spearman"] = spearman_with_ci(
                r["tpi"], r["expert_periodicity"])
        if {"inter_unit_msssim", "expert_unit_consistency"}.issubset(r.columns):
            report["msssim_vs_expert_spearman"] = spearman_with_ci(
                r["inter_unit_msssim"], r["expert_unit_consistency"])

    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(f"[ok] 统计报告 → {out_path}")
    return report


def main() -> None:
    ap = argparse.ArgumentParser(description="论文统计分析")
    ap.add_argument("--tpi", required=True)
    ap.add_argument("--msssim", default=None)
    ap.add_argument("--ratings", default=None)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    run_analysis(args.tpi, args.msssim, args.ratings, args.out)


if __name__ == "__main__":
    main()

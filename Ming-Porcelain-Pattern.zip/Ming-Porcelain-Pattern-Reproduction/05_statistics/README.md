# 05_statistics — 统计分析（论文 2.5 节）

## 检验清单

| 检验 | 用途 | 论文位置 |
|---|---|---|
| One-way ANOVA + Tukey HSD | 比较 A–E、H 组客观指标 | 3.1 |
| 配对 t 检验 | Lineart vs Canny 预处理器比较 | 3.1 |
| 独立样本 t 检验 + TOST | Group H 与 E 的等价性 | 3.1 / 3.3 |
| TOST 敏感性分析 | ±0.3 / ±0.5 / ±0.7 TPI 边界 | 3.4 |
| Spearman 相关 | 专家评分与指标关系 | 3.2 / 3.3 |
| Cohen's d | 效应量 | 3.4 |
| Benjamini–Hochberg | 多重比较校正（α=0.05） | 2.4 |

## 等价检验边界

| 指标 | TOST 边界 |
|---|---|
| TPI | ±0.5 |
| Inter-unit MS-SSIM | ±0.03 |
| 主观周期评分 | ±0.3 |

## 论文核心统计结论（自检参考）

- TPI 与专家周期评分：**ρ = 0.89**，95% CI [0.80, 0.94]，N = 40，
  Fisher z/SE = 8.67，power > 0.99；
- Inter-unit MS-SSIM 与专家单元一致性：**ρ = 0.83**；
- TPI TOST（±0.5）：p = 0.006；MS-SSIM TOST（±0.03）：p = 0.039；
  专家周期 TOST（±0.3）：p = 0.007；
- Lineart vs Canny：TPI 5.2 vs 4.3（rank-32，配对 t(39) = 4.51，p < 0.01）。

## 运行

```bash
python stats_analysis.py --tpi ../results/tpi.csv \
                         --msssim ../results/inter_unit_msssim.csv \
                         --ratings ../data/ratings.csv \
                         --out ../results/stats_report.json
```

产出 `results/stats_report.json`：各组均值±SD、ANOVA/Tukey、TOST、Spearman 等。

## 输入文件格式

- `tpi.csv`：列 `group, image, tpi_canny, tpi_lineart`
- `inter_unit_msssim.csv`：列 `group, image, inter_unit_msssim`
- `ratings.csv`（可选）：列 `tpi, expert_periodicity, inter_unit_msssim, expert_unit_consistency`

# 明代青花缠枝纹样·周期一致性生成评估框架（复现代码）

本仓库复现论文 **《Quantitative Assessment of Periodic Consistency for Horizontally
Banded Ming Blue-and-White Porcelain Interlocking Floral Patterns》** 的完整方法与
实验流程。

论文提出一个 **"轻量 LoRA 自适应 + 结构控制"** 的生成式评估框架，用于横向带状明代
青花缠枝纹样的数字化再生，并给出两个可量化的评估指标：

- **TPI（Texture Periodicity Index，纹理周期指数）**：刻画纹样单元级周期规律性的客观指标；
- **Inter-unit MS-SSIM**：刻画相邻纹样单元之间一致性的客观指标。

最优配置为 **Stable Diffusion v1.5 + rank-8 LoRA + Lineart ControlNet（guidance 0.8）**，
在 TPI、Inter-unit MS-SSIM 与专家评分上等价于 rank-32 LoRA，同时模型体积减小 75%、
训练时间缩短 50%，可在 6 GB 笔记本 GPU 上运行。

---

## 一、目录结构（按功能分类）

```
Ming-Porcelain-Pattern-Reproduction/
├── README.md                     # 本文件：总说明与复现流程
├── requirements.txt              # Python 依赖
├── run_all.sh                    # 全流程一键执行脚本
├── configs/                      # 所有实验配置
│   ├── lora_train_rank{4,8,16,32}.yaml   # 四档 LoRA 训练配置
│   └── generation_groups.yaml    # A–H 八组生成参数
├── 01_dataset/                   # 数据集构建
│   └── prepare_dataset.py        # 归一化 512×512、3:1 划分、类别统计
├── 02_lora_training/             # LoRA 微调
│   ├── train_lora.py             # 基于 diffusers 的 LoRA 训练脚本
│   └── dataset_toml_template.toml
├── 03_generation/               # 图像生成（ComfyUI）
│   ├── build_workflows.py        # 由组配置生成 ComfyUI workflow JSON
│   ├── generate_groups.py        # 批量调用 ComfyUI API 生成
│   └── workflows/                # A–H 八组 workflow（脚本生成）
├── 04_metrics/                  # ★ 评估指标（论文核心贡献）
│   ├── edge_preprocessors.py     # Canny / Lineart 边缘提取
│   ├── tpi.py                    # TPI 纹理周期指数
│   ├── unit_detection.py         # 纹样单元边界检测
│   ├── inter_unit_msssim.py      # Inter-unit MS-SSIM
│   ├── ms_ssim.py                # MS-SSIM 底层实现
│   └── standard_metrics.py       # SSIM / PSNR / LPIPS / FID 封装
├── 05_statistics/               # 统计分析
│   └── stats_analysis.py         # ANOVA+Tukey、配对 t、TOST、Spearman、Cohen's d、BH 校正
├── 06_robustness/               # 指标鲁棒性
│   └── robustness_test.py        # 高斯噪声 / JPEG / 下采样
├── 07_visualization/            # 论文图件
│   └── plot_figures.py           # Fig.2–Fig.5
└── 08_analysis/                 # 深度分析
    ├── pca_analysis.py           # PCA 内在维度
    └── leave_one_variant_out.py  # 留一纹样泛化
```

---

## 二、复现流程总览（对应论文 Fig.1）

论文流程分为 6 个阶段，与目录一一对应：

| 阶段 | 对应目录 | 论文位置 | 产出 |
|---|---|---|---|
| ① 数据构建 | `01_dataset/` | 2.1 | 160 张 512×512 图（120 训练 / 40 测试） |
| ② LoRA 微调 | `02_lora_training/` | 2.2 | rank 4/8/16/32 四个 LoRA 权重 |
| ③ 图像生成 | `03_generation/` | 2.3 | A–H 八组共 320 张图 + 120 张消融图 |
| ④ 指标评估 | `04_metrics/` | 2.4 | TPI、Inter-unit MS-SSIM、SSIM/PSNR/LPIPS/FID |
| ⑤ 统计分析 | `05_statistics/` | 2.5 | 显著性、等价性、相关性结论 |
| ⑥ 深度分析 | `06/07/08_*` | 3.5–4.4 | 鲁棒性、图件、PCA、留一泛化 |

---

## 三、环境要求

**指标 / 统计部分（可在 CPU 上运行，无 GPU 要求）：**

```bash
pip install -r requirements.txt
```

**生成 / 训练部分（需 NVIDIA GPU，建议 ≥6 GB 显存）：**

- Windows 11 / Ubuntu + Python 3.10
- PyTorch 2.0.1+cu118、Diffusers 0.24.0、Transformers 4.36.0
- ComfyUI v0.3.0、controlnet_aux v0.0.7、xFormers 0.0.23
- LoRA 训练使用 SD-Trainer Mikazuki v0.6.5（或本文档提供的 `train_lora.py`）

---

## 四、快速开始

### 0. 安装依赖

```bash
pip install -r requirements.txt
```

### 1. 构建数据集（①）

将原始博物馆图放入 `01_dataset/raw/`，按类别分子目录
（`passionflower_lotus / peony / chrysanthemum / grape_rolls`），然后：

```bash
cd 01_dataset
python prepare_dataset.py --raw_dir raw --out_dir ../data/processed --seed 42
```

产出：`data/processed/train/`（120 张）、`data/processed/test/`（40 张）与
`data/processed/dataset_stats.json`（类别分布）。

### 2. 训练 LoRA（②）

```bash
cd 02_lora_training
python train_lora.py --config ../configs/lora_train_rank8.yaml
# 依次执行 rank4 / rank8 / rank16 / rank32
```

### 3. 生成图像（③）

```bash
cd 03_generation
python build_workflows.py --config ../configs/generation_groups.yaml --out_dir workflows
python generate_groups.py --workflow_dir workflows --out_dir ../data/generated
```

产出：`data/generated/{A..H}/`，每组 40 张。

### 4. 计算指标（④）

```bash
cd 04_metrics
python tpi.py --pred_dir ../data/generated --ref_dir ../data/processed/train --out ../results/tpi.csv
python inter_unit_msssim.py --pred_dir ../data/generated --out ../results/inter_unit_msssim.csv
python standard_metrics.py --pred_dir ../data/generated --ref_dir ../data/processed/train --out ../results/standard_metrics.csv
```

### 5. 统计分析（⑤）

```bash
cd ../05_statistics
python stats_analysis.py --tpi ../results/tpi.csv \
                         --msssim ../results/inter_unit_msssim.csv \
                         --ratings ../data/ratings.csv \
                         --out ../results/stats_report.json
```

### 6. 鲁棒性 / 图件 / 深度分析（⑥）

```bash
cd ../06_robustness && python robustness_test.py --test_dir ../data/processed/test --out ../results/robustness.csv
cd ../07_visualization && python plot_figures.py --results ../results --out ../figures
cd ../08_analysis && python pca_analysis.py --train_dir ../data/processed/train --out ../results/pca.json
python leave_one_variant_out.py --config ../configs/generation_groups.yaml --out ../results/lovo.csv
```

> 一键执行（指标与统计部分）：`bash run_all.sh`
> 生成与训练部分因依赖 GPU 与 ComfyUI，请按上面步骤单独执行。

---

## 五、核心指标速查

| 指标 | 定义 | 论文结论 |
|---|---|---|
| **TPI** | 边缘图垂直投影自相关前三个峰值之和 ÷ 3 倍非峰值区标准差 | 与专家周期评分 ρ=0.89 |
| **Inter-unit MS-SSIM** | 相邻纹样单元归一化后的平均 MS-SSIM | 与专家单元一致性评分 ρ=0.83 |
| SSIM / PSNR | 结构相似度 / 峰值信噪比 | Lineart 0.788 vs Canny 0.771 |
| LPIPS / FID | 感知距离 / 分布距离 | 仅作参考 |

> 说明：仓库仅包含**方法与代码**。原始博物馆图像因机构限制不可再分发；
> 生成的图像与派生标注 / 评分可在论文接收后按需提供。

---

## 六、引用

如使用本代码，请引用原文：

```
Zhang X, Galkin D. Quantitative Assessment of Periodic Consistency for Horizontally
Banded Ming Blue-and-White Porcelain Interlocking Floral Patterns.
```
